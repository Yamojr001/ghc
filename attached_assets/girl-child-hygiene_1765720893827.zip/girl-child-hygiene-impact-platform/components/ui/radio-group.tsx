import * as React from "react"
import { cn } from "@/utils"
import { Circle } from "lucide-react"

const RadioGroupContext = React.createContext<any>(null);

const RadioGroup = React.forwardRef<HTMLDivElement, any>(({ className, value, onValueChange, ...props }, ref) => {
  return (
    <RadioGroupContext.Provider value={{ value, onValueChange }}>
      <div className={cn("grid gap-2", className)} ref={ref} {...props} />
    </RadioGroupContext.Provider>
  )
})
RadioGroup.displayName = "RadioGroup"

const RadioGroupItem = React.forwardRef<HTMLButtonElement, any>(({ className, value: itemValue, ...props }, ref) => {
  const { value, onValueChange } = React.useContext(RadioGroupContext);
  const checked = value === itemValue;
  
  return (
    <button
      type="button"
      role="radio"
      aria-checked={checked}
      ref={ref}
      onClick={() => onValueChange(itemValue)}
      className={cn(
        "aspect-square h-4 w-4 rounded-full border border-gray-400 text-rose-600 shadow focus:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 flex items-center justify-center",
        checked ? "border-rose-600 text-rose-600" : "",
        className
      )}
      {...props}
    >
      {checked && <div className="h-2.5 w-2.5 rounded-full bg-current" />}
    </button>
  )
})
RadioGroupItem.displayName = "RadioGroupItem"

export { RadioGroup, RadioGroupItem }