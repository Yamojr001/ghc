import React, { useState, useEffect, useRef } from 'react';
import { motion, useInView } from 'framer-motion';

export default function ImpactCounter({
  value,
  label,
  icon: Icon,
  suffix = '',
  prefix = '',
  duration = 2000
}: any) {
  const [count, setCount] = useState(0);
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  useEffect(() => {
    if (!isInView) return;

    let startTime: number;
    const target = parseInt(String(value).replace(/,/g, '')) || 0;

    const animate = (timestamp: number) => {
      if (!startTime) startTime = timestamp;
      const progress = Math.min((timestamp - startTime) / duration, 1);
      const easeOut = 1 - Math.pow(1 - progress, 3);
      setCount(Math.floor(easeOut * target));
      
      if (progress < 1) {
        requestAnimationFrame(animate);
      } else {
        setCount(target);
      }
    };

    requestAnimationFrame(animate);

  }, [isInView, value, duration]);

  const formatNumber = (num: number) => {
    if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
    if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
    return num.toLocaleString();
  };

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 20 }}
      animate={isInView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.6, ease: "easeOut" }}
      className="text-center group"
    >
      <div className="inline-flex items-center justify-center w-16 h-16 mb-4 rounded-2xl bg-gradient-to-br from-rose-500/10 to-amber-500/10 group-hover:from-rose-500/20 group-hover:to-amber-500/20 transition-all duration-300">
        {Icon && <Icon className="w-8 h-8 text-rose-600" />}
      </div>
      <div className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-rose-600 to-amber-600 bg-clip-text text-transparent mb-2">
        {prefix}{formatNumber(count)}{suffix}
      </div>
      <div className="text-gray-600 font-medium text-sm uppercase tracking-wider">
        {label}
      </div>
    </motion.div>
  );
}