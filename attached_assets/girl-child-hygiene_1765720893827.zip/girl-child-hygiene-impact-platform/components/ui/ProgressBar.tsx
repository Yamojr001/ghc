import React from 'react';
import { motion } from 'framer-motion';

export default function ProgressBar({
  current,
  target,
  label,
  showAmount = true,
  size = 'md',
  color = 'rose'
}: any) {
  const percentage = Math.min((current / target) * 100, 100);

  const sizeClasses: any = {
    sm: 'h-2',
    md: 'h-3',
    lg: 'h-4'
  };

  const colorClasses: any = {
    rose: 'from-rose-500 to-rose-600',
    amber: 'from-amber-500 to-amber-600',
    emerald: 'from-emerald-500 to-emerald-600',
    blue: 'from-blue-500 to-blue-600'
  };

  return (
    <div className="w-full">
      {(label || showAmount) && (
        <div className="flex justify-between items-center mb-2">
          {label && <span className="text-sm font-medium text-gray-700">{label}</span>}
          {showAmount && (
            <span className="text-sm text-gray-500">
              ${current?.toLocaleString()} / ${target?.toLocaleString()}
            </span>
          )}
        </div>
      )}
      <div className={`w-full bg-gray-200 rounded-full ${sizeClasses[size]} overflow-hidden`}>
        <motion.div
          initial={{ width: 0 }}
          animate={{ width: `${percentage}%` }}
          transition={{ duration: 1.5, ease: "easeOut" }}
          className={`h-full rounded-full bg-gradient-to-r ${colorClasses[color]}`}
        />
      </div>
      <div className="flex justify-end mt-1">
        <span className="text-xs font-semibold text-gray-600">{percentage.toFixed(1)}%</span>
      </div>
    </div>
  );
}