import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Menu, X, Heart, ChevronDown,
  Users, BookOpen, Sparkles, Building2,
  Info, Phone, Newspaper, Image,
  LogIn, User
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { base44 } from '@/services/base44Client';

const navItems = [
  { name: 'Home', href: 'Home' },
  {
    name: 'About',
    href: 'About',
    children: [
      { name: 'Our Story', href: 'About', icon: Info },
      { name: 'Our Team', href: 'Team', icon: Users },
    ]
  },
  {
    name: 'Programs',
    href: 'Programs',
    children: [
      { name: 'All Programs', href: 'Programs', icon: Sparkles },
      { name: 'Menstrual Hygiene', href: 'Programs?program=hygiene', icon: Heart },
      { name: 'Girl Education', href: 'Programs?program=education', icon: BookOpen },
      { name: 'Pad Production', href: 'Programs?program=training', icon: Building2 },
    ]
  },
  { name: 'Impact', href: 'Impact' },
  { name: 'Transparency', href: 'Transparency' },
  {
    name: 'Media',
    href: 'Blog',
    children: [
      { name: 'Blog & News', href: 'Blog', icon: Newspaper },
      { name: 'Gallery', href: 'Gallery', icon: Image },
    ]
  },
  { name: 'Get Involved', href: 'Volunteer' },
  { name: 'Contact', href: 'Contact' },
];

export default function Header() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);
  const [user, setUser] = useState<any>(null);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    
    // Check if user is logged in
    const checkAuth = async () => {
      const userData = await base44.auth.me();
      setUser(userData);
    };
    checkAuth();

    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const isAdmin = user?.role === 'admin' || user?.role === 'super_admin';

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${isScrolled ? 'bg-white/95 backdrop-blur-md shadow-lg py-2' : 'bg-transparent py-4'}`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <Link to={createPageUrl('Home')} className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-rose-500 to-amber-500 flex items-center justify-center shadow-lg">
              <Heart className="w-7 h-7 text-white" fill="white" />
            </div>
            <div className="hidden sm:block">
              <div className={`font-bold text-lg leading-tight ${isScrolled ? 'text-gray-900' : 'text-white'}`}>
                Girl Child Hygiene
              </div>
              <div className={`text-xs ${isScrolled ? 'text-rose-600' : 'text-rose-200'}`}>
                Education & Impact
              </div>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-1">
            {navItems.map((item) => (
              <div
                key={item.name}
                className="relative"
                onMouseEnter={() => item.children && setActiveDropdown(item.name)}
                onMouseLeave={() => setActiveDropdown(null)}
              >
                <Link
                  to={createPageUrl(item.href)}
                  className={`px-4 py-2 rounded-lg text-sm font-medium transition-all flex items-center gap-1 ${
                    isScrolled
                      ? 'text-gray-700 hover:text-rose-600 hover:bg-rose-50'
                      : 'text-white/90 hover:text-white hover:bg-white/10'
                  }`}
                >
                  {item.name}
                  {item.children && <ChevronDown className="w-4 h-4" />}
                </Link>

                {/* Dropdown */}
                <AnimatePresence>
                  {item.children && activeDropdown === item.name && (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: 10 }}
                      transition={{ duration: 0.2 }}
                      className="absolute top-full left-0 mt-2 w-56 bg-white rounded-xl shadow-xl border border-gray-100 overflow-hidden"
                    >
                      {item.children.map((child) => (
                        <Link
                          key={child.name}
                          to={createPageUrl(child.href)}
                          className="flex items-center gap-3 px-4 py-3 text-gray-700 hover:bg-rose-50 hover:text-rose-600 transition-colors"
                        >
                          {child.icon && <child.icon className="w-5 h-5 text-rose-400" />}
                          <span className="text-sm font-medium">{child.name}</span>
                        </Link>
                      ))}
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            ))}
          </nav>

          {/* CTA Buttons */}
          <div className="hidden lg:flex items-center gap-4">
            {isAdmin ? (
              <Link to={createPageUrl('AdminDashboard')}>
                <Button 
                  variant="outline" 
                  className={`border ${isScrolled ? 'border-gray-300 text-gray-700' : 'border-white/30 text-white'}`}
                >
                  <User className="w-4 h-4 mr-2" />
                  Admin Panel
                </Button>
              </Link>
            ) : user ? (
              <Link to={createPageUrl('AdminDashboard')}>
                <Button 
                  variant="outline" 
                  className={`border ${isScrolled ? 'border-gray-300 text-gray-700' : 'border-white/30 text-white'}`}
                >
                  <User className="w-4 h-4 mr-2" />
                  Dashboard
                </Button>
              </Link>
            ) : (
              <Link to={createPageUrl('Login')}>
                <Button 
                  variant="outline" 
                  className={`border ${isScrolled ? 'border-gray-300 text-gray-700' : 'border-white/30 text-white'}`}
                >
                  <LogIn className="w-4 h-4 mr-2" />
                  Login
                </Button>
              </Link>
            )}
            
            <Link to={createPageUrl('Donate')}>
              <Button className="bg-gradient-to-r from-rose-500 to-amber-500 hover:from-rose-600 hover:to-amber-600 text-white shadow-lg shadow-rose-500/25 px-6">
                <Heart className="w-4 h-4 mr-2" />
                Donate Now
              </Button>
            </Link>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className={`lg:hidden p-2 rounded-lg ${isScrolled ? 'text-gray-700' : 'text-white'}`}
          >
            {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="lg:hidden bg-white border-t shadow-xl overflow-hidden"
          >
            <div className="max-w-7xl mx-auto px-4 py-4 space-y-1">
              {navItems.map((item) => (
                <div key={item.name}>
                  <Link
                    to={createPageUrl(item.href)}
                    onClick={() => setIsMobileMenuOpen(false)}
                    className="block px-4 py-3 rounded-lg text-gray-700 hover:bg-rose-50 hover:text-rose-600 font-medium"
                  >
                    {item.name}
                  </Link>
                  {item.children && (
                    <div className="pl-6 space-y-1">
                      {item.children.map((child) => (
                        <Link
                          key={child.name}
                          to={createPageUrl(child.href)}
                          onClick={() => setIsMobileMenuOpen(false)}
                          className="flex items-center gap-3 px-4 py-2 rounded-lg text-gray-600 hover:bg-rose-50 hover:text-rose-600"
                        >
                          {child.icon && <child.icon className="w-4 h-4" />}
                          <span className="text-sm">{child.name}</span>
                        </Link>
                      ))}
                    </div>
                  )}
                </div>
              ))}
              
              {/* Mobile Login/Admin Button */}
              {isAdmin ? (
                <Link
                  to={createPageUrl('AdminDashboard')}
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="block"
                >
                  <Button className="w-full mt-4" variant="outline">
                    <User className="w-4 h-4 mr-2" />
                    Admin Panel
                  </Button>
                </Link>
              ) : user ? (
                <Link
                  to={createPageUrl('AdminDashboard')}
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="block"
                >
                  <Button className="w-full mt-4" variant="outline">
                    <User className="w-4 h-4 mr-2" />
                    Dashboard
                  </Button>
                </Link>
              ) : (
                <Link
                  to={createPageUrl('Login')}
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="block"
                >
                  <Button className="w-full mt-4" variant="outline">
                    <LogIn className="w-4 h-4 mr-2" />
                    Login
                  </Button>
                </Link>
              )}
              
              {/* Donate Button */}
              <Link
                to={createPageUrl('Donate')}
                onClick={() => setIsMobileMenuOpen(false)}
                className="block"
              >
                <Button className="w-full mt-4 bg-gradient-to-r from-rose-500 to-amber-500 text-white">
                  <Heart className="w-4 h-4 mr-2" />
                  Donate Now
                </Button>
              </Link>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}