import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import {
  LayoutDashboard, Heart, Package, DollarSign,
  Users, FileText, BarChart3, Settings, LogOut,
  MapPin, Image, MessageSquare, Bell, Shield
} from 'lucide-react';
import { base44 } from '@/services/base44Client';

const menuItems = [
  { icon: LayoutDashboard, label: 'Dashboard', page: 'AdminDashboard' },
  { icon: Heart, label: 'Donations', page: 'AdminDonations' },
  { icon: Package, label: 'Distributions', page: 'AdminDistributions' },
  { icon: DollarSign, label: 'Expenses', page: 'AdminExpenses' },
  { icon: Users, label: 'Users & Roles', page: 'AdminUsers' },
  { icon: FileText, label: 'Content', page: 'AdminContent' },
  { icon: BarChart3, label: 'Reports', page: 'AdminReports' },
];

export default function AdminSidebar({ user }: { user: any }) {
  const location = useLocation();
  const currentPath = location.pathname;

  const handleLogout = () => {
    base44.auth.logout('/');
  };

  return (
    <aside className="w-64 bg-gray-900 min-h-screen flex flex-col sticky top-0 h-screen">
      {/* Logo */}
      <div className="p-6 border-b border-gray-800">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-rose-500 to-amber-500 flex items-center justify-center">
            <Heart className="w-6 h-6 text-white" fill="white" />
          </div>
          <div>
            <div className="font-bold text-white text-sm">GCHE Admin</div>
            <div className="text-xs text-gray-400">Management Portal</div>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
        {menuItems.map((item) => {
          const isActive = currentPath.includes(item.page);
          return (
            <Link
              key={item.page}
              to={createPageUrl(item.page)}
              className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
                isActive
                  ? 'bg-gradient-to-r from-rose-500 to-amber-500 text-white'
                  : 'text-gray-400 hover:text-white hover:bg-gray-800'
              }`}
            >
              <item.icon className="w-5 h-5" />
              <span className="font-medium">{item.label}</span>
            </Link>
          );
        })}
      </nav>

      {/* Field Officer Link */}
      <div className="p-4 border-t border-gray-800">
        <Link
          to={createPageUrl('FieldOfficer')}
          className="flex items-center gap-3 px-4 py-3 rounded-xl text-gray-400 hover:text-white hover:bg-gray-800 transition-all"
        >
          <MapPin className="w-5 h-5" />
          <span className="font-medium">Field Officer</span>
        </Link>
      </div>

      {/* User Profile */}
      <div className="p-4 border-t border-gray-800">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-full bg-gray-700 flex items-center justify-center">
            <span className="text-white font-semibold">
              {user?.full_name?.charAt(0) || 'A'}
            </span>
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-white font-medium text-sm truncate">
              {user?.full_name || 'Admin User'}
            </div>
            <div className="text-gray-400 text-xs truncate">
              {user?.email || 'admin@example.com'}
            </div>
          </div>
        </div>
        <button
          onClick={handleLogout}
          className="flex items-center gap-2 text-gray-400 hover:text-white text-sm w-full px-2 py-2 rounded-lg hover:bg-gray-800 transition-all"
        >
          <LogOut className="w-4 h-4" />
          Sign Out
        </button>
      </div>
    </aside>
  );
}