import React, { ReactNode, useEffect, useState } from 'react';
import AdminSidebar from './AdminSidebar';
import AdminHeader from './AdminHeader';
import { base44 } from '@/services/base44Client';

interface AdminLayoutProps {
  children: ReactNode;
  title?: string;
  subtitle?: string;
  header?: boolean;
}

export default function AdminLayout({ 
  children, 
  title = 'Dashboard',
  subtitle = '',
  header = true 
}: AdminLayoutProps) {
  const [user, setUser] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const checkAuth = async () => {
      try {
        const userData = await base44.auth.me();
        setUser(userData);
        
        // Redirect to login if not authenticated
        if (!userData) {
          window.location.href = '/#/Login';
        }
      } catch (error) {
        console.error('Auth error:', error);
        window.location.href = '/#/Login';
      } finally {
        setIsLoading(false);
      }
    };

    checkAuth();
  }, []);

  if (isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-gray-100">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-rose-500 border-t-transparent rounded-full animate-spin mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return null; // Will redirect in useEffect
  }

  return (
    <div className="flex min-h-screen bg-gray-100">
      <AdminSidebar user={user} />
      <main className="flex-1">
        {header && <AdminHeader title={title} subtitle={subtitle} />}
        <div className="p-6">
          {children}
        </div>
      </main>
    </div>
  );
}