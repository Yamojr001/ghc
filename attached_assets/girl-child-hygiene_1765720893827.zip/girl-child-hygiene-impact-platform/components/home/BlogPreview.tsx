import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { Calendar, ArrowRight, User } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import SectionHeading from '@/components/ui/SectionHeading';
import { format } from 'date-fns';

const defaultPosts = [
  // {
  //   id: 1,
  //   title: 'Breaking the Silence: Menstrual Health Education in Rural Schools',
  //   excerpt: 'How our hygiene workshops are transforming attitudes and keeping girls in school across 50 communities.',
  //   featured_image: 'https://images.unsplash.com/photo-1577896851231-70ef18881754?w=600&q=80',
  //   category: 'education',
  //   author_name: 'Dr. Amina Ibrahim',
  //   created_date: new Date().toISOString(),
  //   slug: 'breaking-silence-menstrual-health'
  // },
  // {
  //   id: 2,
  //   title: '500 Women Trained: Celebrating Our Pad Production Milestone',
  //   excerpt: 'A look back at three years of empowering women through sustainable livelihood training.',
  //   featured_image: 'https://images.unsplash.com/photo-1556761175-b413da4baf72?w=600&q=80',
  //   category: 'impact_story',
  //   author_name: 'Grace Okonkwo',
  //   created_date: new Date(Date.now() - 86400000 * 3).toISOString(),
  //   slug: '500-women-trained-milestone'
  // },
  // {
  //   id: 3,
  //   title: 'Back to School 2024: 5,000 Girls Ready for Success',
  //   excerpt: 'Our annual back-to-school drive provides uniforms, supplies, and hope to thousands of girls.',
  //   featured_image: 'https://images.unsplash.com/photo-1503676260728-1c00da094a0b?w=600&q=80',
  //   category: 'news',
  //   author_name: 'James Mensah',
  //   created_date: new Date(Date.now() - 86400000 * 7).toISOString(),
  //   slug: 'back-to-school-2024'
  // }
];

const categoryColors: any = {
  news: 'bg-blue-100 text-blue-700',
  impact_story: 'bg-rose-100 text-rose-700',
  education: 'bg-amber-100 text-amber-700',
  health: 'bg-emerald-100 text-emerald-700',
  community: 'bg-purple-100 text-purple-700'
};

export default function BlogPreview({ posts = defaultPosts }: any) {
  const displayPosts = posts.length > 0 ? posts.slice(0, 3) : defaultPosts;

  return (
    <section className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <SectionHeading
          title="Latest Stories"
          subtitle="News, impact stories, and updates from our work in the field"
        />

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {displayPosts.map((post: any, index: number) => (
            <motion.article
              key={post.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="group"
            >
              <Link to={createPageUrl(`BlogPost?slug=${post.slug}`)}>
                <div className="bg-white rounded-2xl overflow-hidden shadow-md hover:shadow-xl transition-all duration-300 border border-gray-100 h-full flex flex-col">
                  {/* Image */}
                  <div className="relative h-52 overflow-hidden">
                    <img
                      src={post.featured_image}
                      alt={post.title}
                      className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute top-4 left-4">
                      <Badge className={categoryColors[post.category] || categoryColors.news}>
                        {post.category?.replace('_', ' ')}
                      </Badge>
                    </div>
                  </div>

                  {/* Content */}
                  <div className="p-6 flex-1 flex flex-col">
                    <h3 className="text-lg font-bold text-gray-900 mb-3 line-clamp-2 group-hover:text-rose-600 transition-colors">
                      {post.title}
                    </h3>
                    <p className="text-gray-600 text-sm mb-4 line-clamp-2 flex-1">
                      {post.excerpt}
                    </p>

                    {/* Meta */}
                    <div className="flex items-center justify-between text-sm text-gray-500 pt-4 border-t">
                      <div className="flex items-center gap-2">
                        <User className="w-4 h-4" />
                        <span>{post.author_name}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Calendar className="w-4 h-4" />
                        <span>{format(new Date(post.created_date || post.created_at || Date.now()), 'MMM d, yyyy')}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </Link>
            </motion.article>
          ))}
        </div>

        {/* View All CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mt-12"
        >
          <Link to={createPageUrl('Blog')}>
            <Button variant="outline" className="border-2">
              View All Stories
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </Link>
        </motion.div>
      </div>
    </section>
  );
}