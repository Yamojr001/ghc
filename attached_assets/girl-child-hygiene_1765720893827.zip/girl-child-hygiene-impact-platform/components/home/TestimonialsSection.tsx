import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Quote, ChevronLeft, ChevronRight, Star } from 'lucide-react';
import SectionHeading from '@/components/ui/SectionHeading';

const defaultTestimonials = [
  {
    id: 1,
    name: 'Amara Okafor',
    role: 'Beneficiary, Age 15',
    location: 'Lagos, Nigeria',
    image: 'https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?w=400&q=80',
    quote: 'Before receiving the sanitary pads, I used to miss school every month. Now I never miss a day, and my grades have improved so much!',
    category: 'beneficiary'
  },
  {
    id: 2,
    name: 'Sarah Mitchell',
    role: 'Monthly Donor',
    location: 'London, UK',
    image: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400&q=80',
    quote: 'Seeing the real impact reports and photos from the field gives me confidence that my donations are truly making a difference.',
    category: 'donor'
  },
  {
    id: 3,
    name: 'Grace Mensah',
    role: 'Pad Production Trainee',
    location: 'Accra, Ghana',
    image: 'https://images.unsplash.com/photo-1489424731084-a5d8b219a5bb?w=400&q=80',
    quote: 'The training changed my life. I now run my own business producing reusable pads and employ three other women from my village.',
    category: 'beneficiary'
  },
  {
    id: 4,
    name: 'James Okonkwo',
    role: 'School Principal',
    location: 'Enugu, Nigeria',
    image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&q=80',
    quote: 'Girl attendance at our school has increased by 40% since the program started. The impact on education is remarkable.',
    category: 'partner'
  }
];

export default function TestimonialsSection({ testimonials = defaultTestimonials }: any) {
  const [currentIndex, setCurrentIndex] = useState(0);

  const next = () => {
    setCurrentIndex((prev) => (prev + 1) % testimonials.length);
  };

  const prev = () => {
    setCurrentIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length);
  };

  const current = testimonials[currentIndex];

  if (!current) return null;

  return (
    <section className="py-24 bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute top-20 left-10 w-64 h-64 bg-rose-500/10 rounded-full blur-3xl" />
      <div className="absolute bottom-20 right-10 w-64 h-64 bg-amber-500/10 rounded-full blur-3xl" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <SectionHeading
          title="Voices of Impact"
          subtitle="Real stories from the girls, donors, and communities we serve"
          light
        />

        <div className="relative max-w-4xl mx-auto">
          {/* Main Testimonial Card */}
          <AnimatePresence mode="wait">
            <motion.div
              key={current.id}
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -50 }}
              transition={{ duration: 0.4 }}
              className="bg-white/10 backdrop-blur-lg rounded-3xl p-8 md:p-12 border border-white/10"
            >
              <div className="flex flex-col md:flex-row gap-8 items-center">
                {/* Image */}
                <div className="relative flex-shrink-0">
                  <div className="w-32 h-32 md:w-40 md:h-40 rounded-full overflow-hidden border-4 border-white/20">
                    <img
                      src={current.image || current.image_url}
                      alt={current.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="absolute -top-2 -right-2 w-12 h-12 rounded-full bg-gradient-to-r from-rose-500 to-amber-500 flex items-center justify-center">
                    <Quote className="w-6 h-6 text-white" />
                  </div>
                </div>

                {/* Content */}
                <div className="flex-1 text-center md:text-left">
                  <div className="flex justify-center md:justify-start gap-1 mb-4">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-5 h-5 text-amber-400" fill="currentColor" />
                    ))}
                  </div>
                  <blockquote className="text-xl md:text-2xl text-white leading-relaxed mb-6 italic">
                    "{current.quote}"
                  </blockquote>
                  <div>
                    <p className="text-white font-semibold text-lg">{current.name}</p>
                    <p className="text-rose-300">{current.role}</p>
                    <p className="text-gray-400 text-sm mt-1">{current.location}</p>
                  </div>
                </div>
              </div>
            </motion.div>
          </AnimatePresence>

          {/* Navigation */}
          <div className="flex items-center justify-center gap-4 mt-8">
            <button
              onClick={prev}
              className="w-12 h-12 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white transition-colors"
            >
              <ChevronLeft className="w-6 h-6" />
            </button>
            
            {/* Dots */}
            <div className="flex gap-2">
              {testimonials.map((_: any, index: number) => (
                <button
                  key={index}
                  onClick={() => setCurrentIndex(index)}
                  className={`w-3 h-3 rounded-full transition-all ${
                    index === currentIndex 
                      ? 'bg-gradient-to-r from-rose-500 to-amber-500 w-8' 
                      : 'bg-white/30 hover:bg-white/50'
                  }`}
                />
              ))}
            </div>

            <button
              onClick={next}
              className="w-12 h-12 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white transition-colors"
            >
              <ChevronRight className="w-6 h-6" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}