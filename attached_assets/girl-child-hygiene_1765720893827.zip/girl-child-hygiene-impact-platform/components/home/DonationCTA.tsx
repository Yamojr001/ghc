import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { Heart, Package, GraduationCap, Sparkles, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';

const donationOptions = [
  {
    amount: 1,
    title: 'Donate a Pad',
    description: 'Provide essential menstrual hygiene products',
    icon: Package,
    impact: '= 10 sanitary pads',
    color: 'from-rose-500 to-pink-600'
  },
  {
    amount: 2.5,
    title: 'Empower a Girl',
    description: 'Support hygiene education and supplies',
    icon: Sparkles,
    impact: '= 1 month of support',
    color: 'from-amber-500 to-orange-600',
    featured: true
  },
  {
    amount: 5,
    title: 'Send Back to School',
    description: 'Provide school supplies and uniforms',
    icon: GraduationCap,
    impact: '= Full school kit',
    color: 'from-emerald-500 to-teal-600'
  }
];

export default function DonationCTA() {
  return (
    <section className="py-24 bg-white relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0 bg-gradient-to-br from-rose-50 via-white to-amber-50" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <span className="inline-block bg-rose-100 text-rose-700 text-sm font-semibold px-4 py-2 rounded-full mb-4">
            Make a Difference Today
          </span>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-gray-900 mb-4">
            Choose How to Help
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto text-lg">
            Every contribution, no matter the size, directly impacts a girl's life. 
            Select a giving option that resonates with you.
          </p>
        </motion.div>

        {/* Donation Options */}
        <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          {donationOptions.map((option, index) => (
            <motion.div
              key={option.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className={`relative group ${option.featured ? 'md:-mt-4 md:mb-4' : ''}`}
            >
              {option.featured && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-gradient-to-r from-rose-500 to-amber-500 text-white text-xs font-bold px-4 py-1 rounded-full z-10">
                  Most Popular
                </div>
              )}
              <div className={`bg-white rounded-3xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 border-2 ${
                option.featured ? 'border-rose-200' : 'border-gray-100 hover:border-rose-200'
              } h-full flex flex-col`}>
                {/* Icon */}
                <div className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${option.color} flex items-center justify-center mb-6 group-hover:scale-110 transition-transform`}>
                  <option.icon className="w-8 h-8 text-white" />
                </div>

                {/* Amount */}
                <div className="mb-4">
                  <span className="text-4xl font-bold text-gray-900">${option.amount}</span>
                  <span className="text-gray-500 ml-1">minimum</span>
                </div>

                {/* Title & Description */}
                <h3 className="text-xl font-bold text-gray-900 mb-2">{option.title}</h3>
                <p className="text-gray-600 mb-4 flex-1">{option.description}</p>

                {/* Impact */}
                <div className="bg-gray-50 rounded-xl px-4 py-3 mb-6">
                  <p className="text-sm font-medium text-gray-700">
                    <span className="text-rose-600">${option.amount}</span> {option.impact}
                  </p>
                </div>

                {/* CTA */}
                <Link to={createPageUrl(`Donate?amount=${option.amount}&category=${option.title.toLowerCase().replace(/\s/g, '_')}`)}>
                  <Button className={`w-full bg-gradient-to-r ${option.color} hover:opacity-90 text-white py-6`}>
                    Donate ${option.amount}+
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </Link>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Additional CTAs */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mt-12 space-y-4"
        >
          <p className="text-gray-600">
            Want to give more or set up monthly giving?
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Link to={createPageUrl('Donate?type=custom')}>
              <Button variant="outline" className="border-2">
                Custom Amount
              </Button>
            </Link>
            <Link to={createPageUrl('Donate?type=monthly')}>
              <Button variant="outline" className="border-2">
                <Heart className="w-4 h-4 mr-2 text-rose-500" />
                Monthly Giving
              </Button>
            </Link>
            <Link to={createPageUrl('Donate?type=corporate')}>
              <Button variant="outline" className="border-2">
                Corporate Sponsorship
              </Button>
            </Link>
          </div>
        </motion.div>
      </div>
    </section>
  );
}