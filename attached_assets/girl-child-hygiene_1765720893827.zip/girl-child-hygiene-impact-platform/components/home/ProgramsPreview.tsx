import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { Heart, BookOpen, Factory, ArrowRight, Check, Users } from 'lucide-react';
import { Button } from '@/components/ui/button';
import SectionHeading from '@/components/ui/SectionHeading';

const defaultPrograms = [
  {
    id: 'hygiene',
    icon: Heart,
    title: 'Menstrual Hygiene Support',
    description: 'Providing free sanitary pads and hygiene education to keep girls in school and healthy.',
    image: 'https://images.unsplash.com/photo-1594708767771-a7502209ff51?w=600&q=80',
    color: 'from-rose-500 to-pink-600',
    bgColor: 'bg-rose-50',
    features: [
      'Free monthly pad distribution',
      'Hygiene education workshops',
      'Health counseling services',
      'Community awareness programs'
    ],
    impact: '45,000+ girls supported'
  },
  {
    id: 'education',
    icon: BookOpen,
    title: 'Girl Child Education',
    description: 'Back-to-school programs providing supplies, uniforms, and tuition support.',
    image: 'https://images.unsplash.com/photo-1497633762265-9d179a990aa6?w=600&q=80',
    color: 'from-amber-500 to-orange-600',
    bgColor: 'bg-amber-50',
    features: [
      'School supply distribution',
      'Uniform and shoe support',
      'Tuition assistance',
      'Mentorship programs'
    ],
    impact: '12,000+ girls in school'
  },
  {
    id: 'training',
    icon: Factory,
    title: 'Pad Production Training',
    description: 'Teaching local women to produce reusable sanitary pads for sustainable income.',
    image: 'https://images.unsplash.com/photo-1556761175-b413da4baf72?w=600&q=80',
    color: 'from-emerald-500 to-teal-600',
    bgColor: 'bg-emerald-50',
    features: [
      'Production skills training',
      'Business management',
      'Startup capital support',
      'Market linkages'
    ],
    impact: '500+ women trained'
  }
];

export default function ProgramsPreview({ programs = defaultPrograms }: any) {
  return (
    <section className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <SectionHeading
          title="Our Programs"
          subtitle="Three interconnected initiatives creating lasting change for girls and communities"
        />

        <div className="grid lg:grid-cols-3 gap-8">
          {defaultPrograms.map((program, index) => (
            <motion.div
              key={program.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.15, duration: 0.5 }}
              className="group"
            >
              <div className="bg-white rounded-3xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-500 border border-gray-100 h-full flex flex-col">
                {/* Image */}
                <div className="relative h-56 overflow-hidden">
                  <img
                    src={program.image}
                    alt={program.title}
                    className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-700"
                  />
                  <div className={`absolute inset-0 bg-gradient-to-t ${program.color} opacity-60`} />
                  <div className="absolute top-4 left-4">
                    <div className="w-14 h-14 rounded-2xl bg-white/20 backdrop-blur-sm flex items-center justify-center">
                      <program.icon className="w-7 h-7 text-white" />
                    </div>
                  </div>
                  <div className="absolute bottom-4 left-4 right-4">
                    <span className="inline-block bg-white/90 backdrop-blur-sm text-gray-800 text-sm font-semibold px-3 py-1 rounded-full">
                      {program.impact}
                    </span>
                  </div>
                </div>

                {/* Content */}
                <div className="p-6 flex-1 flex flex-col">
                  <h3 className="text-xl font-bold text-gray-900 mb-3 group-hover:text-rose-600 transition-colors">
                    {program.title}
                  </h3>
                  <p className="text-gray-600 mb-4">
                    {program.description}
                  </p>

                  {/* Features */}
                  <ul className="space-y-2 mb-6 flex-1">
                    {program.features.map((feature, i) => (
                      <li key={i} className="flex items-start gap-2 text-sm text-gray-600">
                        <Check className="w-4 h-4 text-emerald-500 mt-0.5 flex-shrink-0" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>

                  {/* CTA */}
                  <Link 
                    to={createPageUrl(`Programs?program=${program.id}`)}
                    className="inline-flex items-center text-rose-600 font-semibold hover:text-rose-700 transition-colors group/link"
                  >
                    Learn More
                    <ArrowRight className="w-4 h-4 ml-2 transform group-hover/link:translate-x-1 transition-transform" />
                  </Link>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* View All CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mt-12"
        >
          <Link to={createPageUrl('Programs')}>
            <Button 
              size="lg" 
              variant="outline"
              className="border-2 border-gray-200 hover:border-rose-500 hover:text-rose-600"
            >
              View All Programs
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </Link>
        </motion.div>
      </div>
    </section>
  );
}