import React from 'react';
import { motion } from 'framer-motion';

const defaultPartners = [
  { name: 'UNICEF', logo: 'https://upload.wikimedia.org/wikipedia/commons/thumb/e/ed/Logo_of_UNICEF.svg/200px-Logo_of_UNICEF.svg.png' },
  { name: 'WHO', logo: 'https://upload.wikimedia.org/wikipedia/commons/thumb/2/26/World_Health_Organization_Logo.svg/200px-World_Health_Organization_Logo.svg.png' },
  { name: 'UN Women', logo: 'https://upload.wikimedia.org/wikipedia/commons/thumb/c/c2/UN_Women_English_Blue.svg/200px-UN_Women_English_Blue.svg.png' },
  { name: 'World Bank', logo: 'https://upload.wikimedia.org/wikipedia/commons/thumb/8/87/The_World_Bank_logo.svg/200px-The_World_Bank_logo.svg.png' },
  { name: 'USAID', logo: 'https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/USAID-Identity.svg/200px-USAID-Identity.svg.png' },
  { name: 'Gates Foundation', logo: 'https://upload.wikimedia.org/wikipedia/commons/thumb/2/2a/Bill_%26_Melinda_Gates_Foundation_logo.svg/200px-Bill_%26_Melinda_Gates_Foundation_logo.svg.png' },
];

export default function PartnersSection({ partners = defaultPartners }: any) {
  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <p className="text-rose-600 font-semibold text-sm uppercase tracking-wider mb-2">
            Trusted By
          </p>
          <h3 className="text-2xl font-bold text-gray-900">
            Our Partners & Supporters
          </h3>
        </motion.div>

        {/* Partner Logos */}
        <div className="relative overflow-hidden">
          <div className="flex items-center justify-center flex-wrap gap-12">
            {partners.map((partner: any, index: number) => (
              <motion.div
                key={partner.name}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="grayscale hover:grayscale-0 opacity-60 hover:opacity-100 transition-all duration-300"
              >
                {partner.logo || partner.logo_url ? (
                   <img src={partner.logo || partner.logo_url} alt={partner.name} className="h-12 object-contain" />
                ) : (
                  <div className="h-12 flex items-center">
                    <div className="text-2xl font-bold text-gray-400 tracking-wider">
                      {partner.name}
                    </div>
                  </div>
                )}
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}