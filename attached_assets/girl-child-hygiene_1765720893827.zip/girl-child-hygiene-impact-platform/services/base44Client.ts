import { apiClient } from './apiClient';

class EntityHandler<T> {
  constructor(private entityName: string) {}

  async list(sort = '-created_at', limit?: number) {
    const params: any = { sort };
    if (limit) params.limit = limit;
    const response = await apiClient.getClient().get(`/entities/${this.entityName}/filter`, { params });
    return response.data;
  }

  async filter(filters: any = {}, sort = '-created_at', limit?: number) {
    const params = { ...filters, sort, limit };
    const response = await apiClient.getClient().get(`/entities/${this.entityName}/filter`, { params });
    return response.data;
  }

  async get(id: string | number) {
    const response = await apiClient.getClient().get(`/entities/${this.entityName}/${id}`);
    return response.data;
  }

  async create(data: any) {
    // Ensure CSRF token is fresh before POST
    await apiClient.refreshCsrf();
    const response = await apiClient.getClient().post(`/entities/${this.entityName}`, data);
    return response.data;
  }

  async update(id: string | number, data: any) {
    await apiClient.refreshCsrf();
    const response = await apiClient.getClient().put(`/entities/${this.entityName}/${id}`, data);
    return response.data;
  }

  async delete(id: string | number) {
    await apiClient.refreshCsrf();
    await apiClient.getClient().delete(`/entities/${this.entityName}/${id}`);
    return true;
  }
}

// Authentication Handler
const auth = {
  async login(credentials: any) {
    await apiClient.refreshCsrf();
    const response = await apiClient.getClient().post('/login', credentials);
    return await this.me();
  },
  
  async register(data: any) {
    await apiClient.refreshCsrf();
    const response = await apiClient.getClient().post('/register', data);
    return await this.me();
  },
  
  async logout(redirectPath = '/') {
    try {
      await apiClient.refreshCsrf();
      await apiClient.getClient().post('/logout');
    } catch (error) {
      console.error('Logout error:', error);
    } finally {
      window.location.href = `/#${redirectPath}`;
    }
  },
  
  async me() {
    try {
      const response = await apiClient.getClient().get('/user');
      return response.data;
    } catch (error) {
      // Don't throw error for 401, just return null
      if ((error as any).response?.status !== 401) {
        console.error('Get user error:', error);
      }
      return null;
    }
  }
};

// File Upload Integration
const integrations = {
  Core: {
    async UploadFile({ file }: { file: File }) {
      await apiClient.refreshCsrf();
      const formData = new FormData();
      formData.append('file', file);
      const response = await apiClient.getClient().post('/upload', formData, {
        headers: { 'Content-Type': 'multipart/form-data' }
      });
      return response.data;
    }
  }
};

// Export structure
export const base44 = {
  auth,
  integrations,
  entities: {
    Donation: new EntityHandler('Donation'),
    Distribution: new EntityHandler('Distribution'),
    BlogPost: new EntityHandler('BlogPost'),
    Partner: new EntityHandler('Partner'),
    Program: new EntityHandler('Program'),
    TeamMember: new EntityHandler('TeamMember'),
    GalleryItem: new EntityHandler('GalleryItem'),
    FAQ: new EntityHandler('FAQ'),
    ImpactReport: new EntityHandler('ImpactReport'),
    Subscriber: new EntityHandler('Subscriber'),
    Volunteer: new EntityHandler('Volunteer'),
    ContactMessage: new EntityHandler('ContactMessage'),
    Expense: new EntityHandler('Expense'),
    AuditLog: new EntityHandler('AuditLog'),
    SiteSettings: new EntityHandler('SiteSettings'),
    User: new EntityHandler('User'),
    Testimonial: new EntityHandler('Testimonial'),
  }
};