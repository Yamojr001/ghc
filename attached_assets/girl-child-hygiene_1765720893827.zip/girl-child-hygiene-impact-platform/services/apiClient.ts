import axios, { AxiosInstance, AxiosError } from 'axios';

const API_URL = 'http://127.0.0.1:8000/api';

class ApiClient {
  private client: AxiosInstance;
  private csrfToken: string | null = null;
  private isRefreshing = false;
  private failedQueue: any[] = [];

  constructor() {
    this.client = axios.create({
      baseURL: API_URL,
      withCredentials: true,
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'X-Requested-With': 'XMLHttpRequest',
      },
    });

    this.setupInterceptors();
    this.initializeCsrf();
  }

  private async initializeCsrf(): Promise<void> {
    try {
      await axios.get('http://127.0.0.1:8000/sanctum/csrf-cookie', {
        withCredentials: true,
      });
      
      // Get CSRF token from cookies
      const cookies = document.cookie.split(';');
      const xsrfCookie = cookies.find(cookie => 
        cookie.trim().startsWith('XSRF-TOKEN=')
      );
      
      if (xsrfCookie) {
        this.csrfToken = decodeURIComponent(xsrfCookie.split('=')[1]);
        console.log('CSRF Token initialized:', this.csrfToken);
      }
    } catch (error) {
      console.warn('CSRF initialization failed:', error);
    }
  }

  private processQueue(error: any, token: string | null = null) {
    this.failedQueue.forEach(prom => {
      if (error) {
        prom.reject(error);
      } else {
        prom.resolve(token);
      }
    });
    this.failedQueue = [];
  }

  private setupInterceptors(): void {
    // Request interceptor
    this.client.interceptors.request.use(
      (config) => {
        // Add CSRF token for mutating requests
        if (['post', 'put', 'delete', 'patch'].includes(config.method?.toLowerCase() || '')) {
          if (this.csrfToken) {
            config.headers['X-XSRF-TOKEN'] = this.csrfToken;
          }
        }
        return config;
      },
      (error) => Promise.reject(error)
    );

    // Response interceptor
    this.client.interceptors.response.use(
      (response) => response,
      async (error: AxiosError) => {
        const originalRequest = error.config;
        
        // Handle 419 CSRF token mismatch
        if (error.response?.status === 419 && originalRequest && !this.isRefreshing) {
          this.isRefreshing = true;
          
          try {
            await this.initializeCsrf();
            
            // Retry the original request
            if (this.csrfToken && originalRequest.headers) {
              originalRequest.headers['X-XSRF-TOKEN'] = this.csrfToken;
            }
            
            this.isRefreshing = false;
            this.processQueue(null, this.csrfToken);
            
            return this.client(originalRequest);
          } catch (refreshError) {
            this.isRefreshing = false;
            this.processQueue(refreshError, null);
            return Promise.reject(refreshError);
          }
        }
        
        // Handle 401 for user endpoint
        if (error.response?.status === 401 && originalRequest?.url?.includes('/user')) {
          // Return null for unauthenticated users
          return Promise.resolve({ data: null });
        }
        
        return Promise.reject(error);
      }
    );
  }

  // Public methods
  public getClient(): AxiosInstance {
    return this.client;
  }

  public async refreshCsrf(): Promise<void> {
    await this.initializeCsrf();
  }
}

// Export singleton instance
export const apiClient = new ApiClient();