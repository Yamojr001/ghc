export interface User {
  id: number;
  name: string;
  email: string;
  role: 'admin' | 'field_officer' | 'user';
  created_at: string;
}

export interface Donation {
  id: number;
  donor_name: string;
  donor_email: string;
  amount: number;
  amount_usd: number;
  currency: string;
  status: 'pending' | 'verified' | 'rejected' | 'refunded';
  category: string;
  payment_method: string;
  is_anonymous: boolean;
  is_recurring: boolean;
  created_at: string;
  // ... other fields
}

export interface Distribution {
  id: number;
  location_name: string;
  beneficiary_count: number;
  items_distributed: number;
  distribution_date: string;
  region: string;
  country: string;
  status: 'pending' | 'approved' | 'rejected';
  field_officer_name?: string;
  photo_urls?: string[];
  gps_latitude?: number;
  gps_longitude?: number;
  created_at: string;
}

export interface BlogPost {
  id: number;
  title: string;
  slug: string;
  excerpt: string;
  content?: string;
  featured_image: string;
  category: string;
  author_name: string;
  status: 'draft' | 'published';
  published_at: string;
  created_at: string;
}

export interface Partner {
  id: number;
  name: string;
  logo_url: string;
  is_featured: boolean;
  is_active: boolean;
}

export interface Testimonial {
  id: number;
  name: string;
  role: string;
  quote: string;
  image_url: string;
  location: string;
  is_featured: boolean;
  is_approved: boolean;
}

export interface Program {
  id: number;
  name: string;
  slug: string;
  description: string;
  short_description: string;
  icon: string;
  image_url: string;
  current_funding: number;
  required_funding: number;
  beneficiaries_reached: number;
}

export interface ImpactReport {
  id: number;
  title: string;
  year: number;
  file_url: string;
  is_published: boolean;
}

export interface Expense {
  id: number;
  title: string;
  amount: number;
  amount_usd: number;
  category: string;
  status: 'pending' | 'approved' | 'rejected';
  expense_date: string;
}

// Response Wrapper if Laravel wraps in 'data' (Standard Resource)
export interface PaginatedResponse<T> {
  data: T[];
  links?: any;
  meta?: any;
}
