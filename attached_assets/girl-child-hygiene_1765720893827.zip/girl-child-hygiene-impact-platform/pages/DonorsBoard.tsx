import React, { useState } from 'react';
import { base44 } from '@/services/base44Client';
import { useQuery } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import { 
  Heart, Trophy, Crown, Medal,
  Globe, Users
} from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

// Country flag emoji helper
const getFlag = (countryCode: string) => {
  if (!countryCode) return '🌍';
  const codePoints = countryCode
    .toUpperCase()
    .split('')
    .map(char => 127397 + char.charCodeAt(0));
  return String.fromCodePoint(...codePoints);
};

export default function DonorsBoard() {
  const [period, setPeriod] = useState('all');

  const { data: donations = [] } = useQuery({
    queryKey: ['donations-verified'],
    queryFn: () => base44.entities.Donation.filter({ status: 'verified' }, '-amount_usd'),
  });

  // Calculate rankings
  const getDonorStats = (donationsList: any[]) => {
    const donorMap: any = {};
    
    donationsList.forEach(d => {
      const key = d.is_anonymous ? 'anonymous_' + d.id : d.donor_email;
      if (!donorMap[key]) {
        donorMap[key] = {
          name: d.is_anonymous ? 'Anonymous Donor' : d.donor_name,
          country: d.donor_country,
          countryCode: d.donor_country_code,
          isAnonymous: d.is_anonymous,
          totalAmount: 0,
          donationCount: 0,
          lastDonation: d.created_date,
        };
      }
      donorMap[key].totalAmount += d.amount_usd || 0;
      donorMap[key].donationCount += 1;
      if (new Date(d.created_date) > new Date(donorMap[key].lastDonation)) {
        donorMap[key].lastDonation = d.created_date;
      }
    });

    return Object.values(donorMap).sort((a: any, b: any) => b.totalAmount - a.totalAmount);
  };

  // Filter by period
  const filterByPeriod = (donationsList: any[], periodType: string) => {
    if (periodType === 'all') return donationsList;
    
    const now = new Date();
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    
    return donationsList.filter(d => new Date(d.created_date) >= startOfMonth);
  };

  const filteredDonations = filterByPeriod(donations, period);
  const rankedDonors: any[] = getDonorStats(filteredDonations);
  
  const topDonors = rankedDonors.slice(0, 3);
  const otherDonors = rankedDonors.slice(3, 50);

  const totalRaised = donations.reduce((acc: number, d: any) => acc + (d.amount_usd || 0), 0);
  const totalDonors = new Set(donations.map((d: any) => d.donor_email)).size;
  const countriesReached = new Set(donations.map((d: any) => d.donor_country_code).filter(Boolean)).size;

  const getRankIcon = (index: number) => {
    switch(index) {
      case 0: return <Crown className="w-6 h-6 text-yellow-500" />;
      case 1: return <Medal className="w-6 h-6 text-gray-400" />;
      case 2: return <Medal className="w-6 h-6 text-amber-600" />;
      default: return null;
    }
  };

  const getRankBg = (index: number) => {
    switch(index) {
      case 0: return 'from-yellow-100 to-amber-100 border-yellow-300';
      case 1: return 'from-gray-100 to-slate-100 border-gray-300';
      case 2: return 'from-amber-50 to-orange-100 border-amber-300';
      default: return 'from-white to-gray-50 border-gray-200';
    }
  };

  return (
    <div className="min-h-screen pt-20 bg-gradient-to-b from-gray-50 to-white">
      {/* Hero */}
      <section className="relative py-16 overflow-hidden bg-gradient-to-br from-rose-600 via-rose-500 to-amber-500">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-10 left-10 w-64 h-64 bg-white rounded-full blur-3xl" />
          <div className="absolute bottom-10 right-10 w-64 h-64 bg-white rounded-full blur-3xl" />
        </div>
        <div className="relative max-w-4xl mx-auto px-4 text-center">
          <Trophy className="w-16 h-16 text-white/80 mx-auto mb-6" />
          <h1 className="text-3xl md:text-5xl font-bold text-white mb-4">
            Our Heroes
          </h1>
          <p className="text-xl text-white/90 max-w-2xl mx-auto">
            Celebrating the generous individuals and organizations making our mission possible.
          </p>
        </div>
      </section>

      {/* Stats */}
      <section className="py-12 -mt-8 relative z-10">
        <div className="max-w-4xl mx-auto px-4">
          <div className="grid grid-cols-3 gap-4">
            {[
              { icon: Heart, label: 'Total Raised', value: `$${totalRaised.toLocaleString()}` },
              { icon: Users, label: 'Donors', value: totalDonors.toLocaleString() },
              { icon: Globe, label: 'Countries', value: countriesReached.toString() },
            ].map((stat, index) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="bg-white rounded-2xl p-6 shadow-lg text-center"
              >
                <stat.icon className="w-8 h-8 text-rose-500 mx-auto mb-2" />
                <div className="text-2xl font-bold text-gray-900">{stat.value}</div>
                <div className="text-sm text-gray-500">{stat.label}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Donors List */}
      <section className="py-12">
        <div className="max-w-4xl mx-auto px-4">
          <Tabs defaultValue="all" onValueChange={setPeriod}>
            <div className="flex justify-center mb-8">
              <TabsList className="bg-gray-100">
                <TabsTrigger value="all">All Time</TabsTrigger>
                <TabsTrigger value="monthly">This Month</TabsTrigger>
              </TabsList>
            </div>

            <TabsContent value="all">
              <DonorsList topDonors={topDonors} otherDonors={otherDonors} getRankIcon={getRankIcon} getRankBg={getRankBg} getFlag={getFlag} />
            </TabsContent>
            <TabsContent value="monthly">
              <DonorsList topDonors={topDonors} otherDonors={otherDonors} getRankIcon={getRankIcon} getRankBg={getRankBg} getFlag={getFlag} />
            </TabsContent>
          </Tabs>
        </div>
      </section>
    </div>
  );
}

function DonorsList({ topDonors, otherDonors, getRankIcon, getRankBg, getFlag }: any) {
  return (
    <>
      {/* Top 3 */}
      {topDonors.length > 0 && (
        <div className="grid md:grid-cols-3 gap-6 mb-12">
          {topDonors.map((donor: any, index: number) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className={`bg-gradient-to-br ${getRankBg(index)} rounded-2xl p-6 border-2 text-center ${
                index === 0 ? 'md:order-2 md:-mt-4' : index === 1 ? 'md:order-1' : 'md:order-3'
              }`}
            >
              <div className="flex justify-center mb-4">
                {getRankIcon(index)}
              </div>
              <div className="text-4xl mb-3">{getFlag(donor.countryCode)}</div>
              <h3 className="text-lg font-bold text-gray-900 mb-1">
                {donor.name}
              </h3>
              <p className="text-sm text-gray-500 mb-3">{donor.country || 'Global'}</p>
              <div className="text-2xl font-bold bg-gradient-to-r from-rose-600 to-amber-600 bg-clip-text text-transparent">
                ${donor.totalAmount.toLocaleString()}
              </div>
              <p className="text-xs text-gray-500 mt-1">
                {donor.donationCount} donation{donor.donationCount !== 1 ? 's' : ''}
              </p>
            </motion.div>
          ))}
        </div>
      )}

      {/* Rest of donors */}
      {otherDonors.length > 0 && (
        <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
          <div className="p-4 bg-gray-50 border-b font-semibold text-gray-700 grid grid-cols-12 gap-4">
            <div className="col-span-1 text-center">#</div>
            <div className="col-span-5">Donor</div>
            <div className="col-span-3 text-center">Country</div>
            <div className="col-span-3 text-right">Amount</div>
          </div>
          <div className="divide-y">
            {otherDonors.map((donor: any, index: number) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.02 }}
                className="p-4 grid grid-cols-12 gap-4 items-center hover:bg-gray-50 transition-colors"
              >
                <div className="col-span-1 text-center font-bold text-gray-400">
                  {index + 4}
                </div>
                <div className="col-span-5">
                  <div className="font-medium text-gray-900">{donor.name}</div>
                  <div className="text-xs text-gray-500">
                    {donor.donationCount} donation{donor.donationCount !== 1 ? 's' : ''}
                  </div>
                </div>
                <div className="col-span-3 text-center">
                  <span className="text-2xl mr-2">{getFlag(donor.countryCode)}</span>
                  <span className="text-sm text-gray-600">{donor.country || 'Global'}</span>
                </div>
                <div className="col-span-3 text-right font-bold text-gray-900">
                  ${donor.totalAmount.toLocaleString()}
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      )}

      {topDonors.length === 0 && otherDonors.length === 0 && (
        <div className="text-center py-16 text-gray-500">
          <Heart className="w-16 h-16 mx-auto mb-4 text-gray-300" />
          <p className="text-lg">No donations yet. Be the first to donate!</p>
        </div>
      )}
    </>
  );
}