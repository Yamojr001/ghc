import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { 
  Heart, BookOpen, Factory, ArrowRight, Check,
  Users
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import ProgressBar from '@/components/ui/ProgressBar';
import SectionHeading from '@/components/ui/SectionHeading';

const programs = [
  {
    id: 'hygiene',
    slug: 'menstrual-hygiene',
    icon: Heart,
    title: 'Menstrual Hygiene Support',
    tagline: 'Dignity Through Hygiene',
    description: 'Our flagship program provides free sanitary pads and comprehensive hygiene education to girls across communities, ensuring that menstruation never becomes a barrier to education.',
    image: 'https://images.unsplash.com/photo-1594708767771-a7502209ff51?w=1200&q=80',
    color: 'from-rose-500 to-pink-600',
    stats: {
      beneficiaries: 45000,
      monthlyTarget: 5000,
      totalTarget: 500000,
      currentFunding: 125000,
      requiredFunding: 500000
    },
    features: [
      'Free monthly pad distribution',
      'Hygiene education workshops',
      'Health counseling services',
      'Menstrual health training',
      'Community awareness programs',
      'School sanitation support'
    ],
    outcomes: [
      { label: 'School Attendance Increase', value: '40%' },
      { label: 'Girls Supported Monthly', value: '5,000+' },
      { label: 'Schools Partnered', value: '350+' },
      { label: 'Communities Reached', value: '85' }
    ]
  },
  {
    id: 'education',
    slug: 'girl-education',
    icon: BookOpen,
    title: 'Girl Child Education',
    tagline: 'Empowering Through Education',
    description: 'Our back-to-school program provides comprehensive support including school supplies, uniforms, tuition assistance, and mentorship to keep girls in school and thriving.',
    image: 'https://images.unsplash.com/photo-1497633762265-9d179a990aa6?w=1200&q=80',
    color: 'from-amber-500 to-orange-600',
    stats: {
      beneficiaries: 12000,
      monthlyTarget: 1000,
      totalTarget: 100000,
      currentFunding: 75000,
      requiredFunding: 300000
    },
    features: [
      'School supply distribution',
      'Uniform and shoe support',
      'Tuition fee assistance',
      'Mentorship programs',
      'Career guidance',
      'After-school tutoring'
    ],
    outcomes: [
      { label: 'Dropout Rate Reduction', value: '60%' },
      { label: 'Girls Enrolled', value: '12,000+' },
      { label: 'Scholarships Given', value: '500+' },
      { label: 'Mentors Active', value: '200+' }
    ]
  },
  {
    id: 'training',
    slug: 'pad-production',
    icon: Factory,
    title: 'Pad Production Training',
    tagline: 'Sustainable Livelihoods',
    description: 'We train local women to produce reusable sanitary pads, creating sustainable income opportunities while ensuring communities have ongoing access to menstrual products.',
    image: 'https://images.unsplash.com/photo-1556761175-b413da4baf72?w=1200&q=80',
    color: 'from-emerald-500 to-teal-600',
    stats: {
      beneficiaries: 500,
      monthlyTarget: 50,
      totalTarget: 5000,
      currentFunding: 45000,
      requiredFunding: 150000
    },
    features: [
      'Production skills training',
      'Business management education',
      'Startup capital support',
      'Equipment provision',
      'Market linkages',
      'Quality certification'
    ],
    outcomes: [
      { label: 'Women Trained', value: '500+' },
      { label: 'Businesses Started', value: '150+' },
      { label: 'Average Income Increase', value: '300%' },
      { label: 'Communities Served', value: '25' }
    ]
  }
];

export default function Programs() {
  return (
    <div className="min-h-screen pt-20">
      {/* Hero Section */}
      <section className="relative py-24 overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?w=1920&q=80"
            alt="Program activities"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-gray-900/95 to-gray-900/80" />
        </div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <span className="inline-block bg-rose-500/20 text-rose-300 text-sm font-semibold px-4 py-2 rounded-full mb-6">
              Our Programs
            </span>
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6">
              Three Pillars of Change
            </h1>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              Our interconnected programs address menstrual hygiene, education access, 
              and economic empowerment to create lasting change for girls and communities.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Programs Detail */}
      {programs.map((program, index) => (
        <section 
          key={program.id}
          id={program.id}
          className={`py-24 ${index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}`}
        >
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className={`grid lg:grid-cols-2 gap-16 items-center ${index % 2 !== 0 ? 'lg:grid-flow-col-dense' : ''}`}>
              {/* Content */}
              <motion.div
                initial={{ opacity: 0, x: index % 2 === 0 ? -30 : 30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                className={index % 2 !== 0 ? 'lg:col-start-2' : ''}
              >
                <div className={`inline-flex items-center gap-2 px-4 py-2 rounded-full bg-gradient-to-r ${program.color} text-white text-sm font-semibold mb-4`}>
                  <program.icon className="w-4 h-4" />
                  {program.tagline}
                </div>
                <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
                  {program.title}
                </h2>
                <p className="text-lg text-gray-600 mb-6">
                  {program.description}
                </p>

                {/* Stats Grid */}
                <div className="grid grid-cols-2 gap-4 mb-8">
                  {program.outcomes.map((outcome) => (
                    <div key={outcome.label} className="bg-gray-50 rounded-xl p-4">
                      <div className={`text-2xl font-bold bg-gradient-to-r ${program.color} bg-clip-text text-transparent`}>
                        {outcome.value}
                      </div>
                      <div className="text-sm text-gray-600">{outcome.label}</div>
                    </div>
                  ))}
                </div>

                {/* Features */}
                <div className="grid sm:grid-cols-2 gap-3 mb-8">
                  {program.features.map((feature) => (
                    <div key={feature} className="flex items-center gap-2 text-gray-700">
                      <Check className="w-5 h-5 text-emerald-500 flex-shrink-0" />
                      <span>{feature}</span>
                    </div>
                  ))}
                </div>

                {/* Progress */}
                <div className="bg-white rounded-xl p-6 shadow-md border border-gray-100 mb-6">
                  <h4 className="font-semibold text-gray-900 mb-4">Funding Progress</h4>
                  <ProgressBar
                    current={program.stats.currentFunding}
                    target={program.stats.requiredFunding}
                    color={program.color.includes('rose') ? 'rose' : program.color.includes('amber') ? 'amber' : 'emerald'}
                  />
                </div>

                <Link to={createPageUrl(`Donate?program=${program.id}`)}>
                  <Button className={`bg-gradient-to-r ${program.color} text-white`}>
                    Support This Program
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </Link>
              </motion.div>

              {/* Image */}
              <motion.div
                initial={{ opacity: 0, x: index % 2 === 0 ? 30 : -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                className={`relative ${index % 2 !== 0 ? 'lg:col-start-1' : ''}`}
              >
                <div className={`absolute -inset-4 bg-gradient-to-r ${program.color} rounded-3xl blur-2xl opacity-20`} />
                <div className="relative">
                  <img
                    src={program.image}
                    alt={program.title}
                    className="rounded-3xl shadow-2xl"
                  />
                  <div className="absolute -bottom-6 -right-6 bg-white rounded-2xl p-4 shadow-xl">
                    <div className="flex items-center gap-3">
                      <div className={`w-12 h-12 rounded-xl bg-gradient-to-r ${program.color} flex items-center justify-center`}>
                        <Users className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <div className="text-2xl font-bold text-gray-900">
                          {program.stats.beneficiaries.toLocaleString()}+
                        </div>
                        <div className="text-sm text-gray-500">Beneficiaries</div>
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            </div>
          </div>
        </section>
      ))}

      {/* How It Works */}
      <section className="py-24 bg-gradient-to-br from-gray-900 to-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <SectionHeading
            title="How We Create Impact"
            subtitle="Our systematic approach ensures sustainable, measurable change"
            light
          />

          <div className="grid md:grid-cols-4 gap-8">
            {[
              { step: '01', title: 'Identify', description: 'Partner with schools and communities to identify girls in need' },
              { step: '02', title: 'Support', description: 'Provide hygiene products, education materials, and training' },
              { step: '03', title: 'Verify', description: 'Field officers document distribution with GPS and photos' },
              { step: '04', title: 'Report', description: 'Share transparent impact reports with all stakeholders' },
            ].map((item, index) => (
              <motion.div
                key={item.step}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="text-center"
              >
                <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gradient-to-r from-rose-500 to-amber-500 text-white text-2xl font-bold mb-4">
                  {item.step}
                </div>
                <h3 className="text-xl font-bold text-white mb-2">{item.title}</h3>
                <p className="text-gray-400">{item.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-24 bg-gradient-to-r from-rose-600 to-amber-600">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
            Ready to Make a Difference?
          </h2>
          <p className="text-xl text-white/90 mb-8">
            Your support can change a girl's life. Choose a program to support today.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Link to={createPageUrl('Donate')}>
              <Button size="lg" className="bg-white text-rose-600 hover:bg-gray-100">
                <Heart className="w-5 h-5 mr-2" />
                Donate Now
              </Button>
            </Link>
            <Link to={createPageUrl('Contact')}>
              <Button size="lg" variant="outline" className="border-2 border-white text-white hover:bg-white/10">
                Partner With Us
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}