import React, { useState } from 'react';
import { base44 } from '@/services/base44Client';
import { useQuery } from '@tanstack/react-query';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Image as ImageIcon, Video, X, ChevronLeft, ChevronRight,
  MapPin
} from 'lucide-react';

const categories = [
  { id: 'all', name: 'All' },
  { id: 'distribution', name: 'Distributions' },
  { id: 'training', name: 'Training' },
  { id: 'education', name: 'Education' },
  { id: 'community', name: 'Community' },
  { id: 'events', name: 'Events' },
];

export default function Gallery() {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedImage, setSelectedImage] = useState<any>(null);
  const [currentIndex, setCurrentIndex] = useState(0);

  const { data: gallery = [] } = useQuery({
    queryKey: ['gallery'],
    queryFn: () => base44.entities.GalleryItem.list('-created_at'),
  });

  const filteredGallery = gallery.filter(
    (item: any) => selectedCategory === 'all' || item.category === selectedCategory
  );

  const openLightbox = (item: any, index: number) => {
    setSelectedImage(item);
    setCurrentIndex(index);
  };

  const closeLightbox = () => {
    setSelectedImage(null);
  };

  const navigateLightbox = (direction: number) => {
    const newIndex = (currentIndex + direction + filteredGallery.length) % filteredGallery.length;
    setCurrentIndex(newIndex);
    setSelectedImage(filteredGallery[newIndex]);
  };

  return (
    <div className="min-h-screen pt-20 bg-gray-50">
      {/* Hero */}
      <section className="relative py-16 bg-white">
        <div className="max-w-6xl mx-auto px-4 text-center">
          <ImageIcon className="w-12 h-12 text-rose-500 mx-auto mb-4" />
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Gallery
          </h1>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Moments captured from our work across communities, schools, and training centers.
          </p>
        </div>
      </section>

      {/* Categories */}
      <section className="py-6 bg-white border-b sticky top-16 z-30">
        <div className="max-w-6xl mx-auto px-4">
          <div className="flex flex-wrap justify-center gap-2">
            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                  selectedCategory === cat.id
                    ? 'bg-rose-500 text-white'
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
              >
                {cat.name}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Gallery Grid */}
      <section className="py-12">
        <div className="max-w-6xl mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {filteredGallery.map((item: any, index: number) => (
              <motion.div
                key={item.id}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.05 }}
                className="group relative aspect-square rounded-xl overflow-hidden cursor-pointer"
                onClick={() => openLightbox(item, index)}
              >
                <img
                  src={item.media_url}
                  alt={item.title}
                  className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity">
                  <div className="absolute bottom-0 left-0 right-0 p-4">
                    <h3 className="text-white font-semibold text-sm line-clamp-1">
                      {item.title}
                    </h3>
                    {item.location && (
                      <p className="text-white/70 text-xs flex items-center gap-1 mt-1">
                        <MapPin className="w-3 h-3" />
                        {item.location}
                      </p>
                    )}
                  </div>
                </div>
                {item.media_type === 'video' && (
                  <div className="absolute top-2 right-2 w-8 h-8 rounded-full bg-white/90 flex items-center justify-center">
                    <Video className="w-4 h-4 text-rose-500" />
                  </div>
                )}
              </motion.div>
            ))}
          </div>
          {filteredGallery.length === 0 && (
            <div className="text-center py-12 text-gray-500">
              No gallery items found.
            </div>
          )}
        </div>
      </section>

      {/* Lightbox */}
      <AnimatePresence>
        {selectedImage && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/95 flex items-center justify-center"
            onClick={closeLightbox}
          >
            <button
              onClick={closeLightbox}
              className="absolute top-4 right-4 text-white/70 hover:text-white z-50"
            >
              <X className="w-8 h-8" />
            </button>

            <button
              onClick={(e) => { e.stopPropagation(); navigateLightbox(-1); }}
              className="absolute left-4 text-white/70 hover:text-white z-50"
            >
              <ChevronLeft className="w-12 h-12" />
            </button>

            <button
              onClick={(e) => { e.stopPropagation(); navigateLightbox(1); }}
              className="absolute right-4 text-white/70 hover:text-white z-50"
            >
              <ChevronRight className="w-12 h-12" />
            </button>

            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="max-w-5xl max-h-[90vh] mx-4"
              onClick={(e) => e.stopPropagation()}
            >
              <img
                src={selectedImage.media_url}
                alt={selectedImage.title}
                className="max-w-full max-h-[80vh] object-contain rounded-lg"
              />
              <div className="mt-4 text-center">
                <h3 className="text-white text-xl font-semibold">{selectedImage.title}</h3>
                {selectedImage.description && (
                  <p className="text-white/70 mt-1">{selectedImage.description}</p>
                )}
                {selectedImage.location && (
                  <p className="text-white/50 text-sm mt-2 flex items-center justify-center gap-1">
                    <MapPin className="w-4 h-4" />
                    {selectedImage.location}
                  </p>
                )}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}