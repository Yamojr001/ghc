import React from 'react';
import { base44 } from '@/services/base44Client';
import { useQuery } from '@tanstack/react-query';
import HeroSection from '@/components/home/HeroSection';
import ImpactStats from '@/components/home/ImpactStats';
import ProgramsPreview from '@/components/home/ProgramsPreview';
import TestimonialsSection from '@/components/home/TestimonialsSection';
import DonationCTA from '@/components/home/DonationCTA';
import PartnersSection from '@/components/home/PartnersSection';
import BlogPreview from '@/components/home/BlogPreview';

export default function Home() {
  const { data: donations = [] } = useQuery({
    queryKey: ['donations-verified'],
    queryFn: () => base44.entities.Donation.filter({ status: 'verified' }),
  });

  const { data: distributions = [] } = useQuery({
    queryKey: ['distributions-approved'],
    queryFn: () => base44.entities.Distribution.filter({ status: 'approved' }),
  });

  const { data: testimonials = [] } = useQuery({
    queryKey: ['testimonials-featured'],
    queryFn: () => base44.entities.Testimonial.filter({ is_featured: true, is_approved: true }),
  });

  const { data: posts = [] } = useQuery({
    queryKey: ['blog-posts'],
    queryFn: () => base44.entities.BlogPost.filter({ status: 'published' }, '-published_at', 3),
  });

  const { data: partners = [] } = useQuery({
    queryKey: ['partners-featured'],
    queryFn: () => base44.entities.Partner.filter({ is_featured: true, is_active: true }),
  });

  return (
    <div className="min-h-screen">
      <HeroSection />
      <ImpactStats donations={donations} distributions={distributions} />
      <ProgramsPreview />
      <DonationCTA />
      <TestimonialsSection testimonials={testimonials.length > 0 ? testimonials : undefined} />
      <PartnersSection partners={partners.length > 0 ? partners : undefined} />
      <BlogPreview posts={posts} />
    </div>
  );
}