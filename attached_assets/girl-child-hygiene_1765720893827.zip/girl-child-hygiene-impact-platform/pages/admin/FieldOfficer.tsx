import React, { useState, useEffect } from 'react';
import { base44 } from '@/services/base44Client';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import { 
  MapPin, Camera, Upload, Calendar, Users, 
  Package, Check, Loader2, Plus, X, Building2
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { format } from 'date-fns';

export default function FieldOfficer() {
  const [user, setUser] = useState<any>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [photos, setPhotos] = useState<string[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [gpsLocation, setGpsLocation] = useState<any>(null);
  const [gpsError, setGpsError] = useState<string | null>(null);

  const [formData, setFormData] = useState({
    location_name: '',
    location_type: '',
    region: '',
    country: '',
    beneficiary_count: '',
    items_distributed: '',
    distribution_date: new Date().toISOString().split('T')[0],
    notes: ''
  });

  const queryClient = useQueryClient();

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const { data: myDistributions = [] } = useQuery({
    queryKey: ['my-distributions', user?.id],
    queryFn: () => base44.entities.Distribution.filter({ 
      field_officer_id: user?.id 
    }, '-created_at', 20),
    enabled: !!user
  });

  const getGPSLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setGpsLocation({
            latitude: position.coords.latitude,
            longitude: position.coords.longitude
          });
          setGpsError(null);
        },
        (error) => {
          setGpsError('Unable to get location. Please enable GPS.');
        }
      );
    } else {
      setGpsError('Geolocation is not supported by this browser.');
    }
  };

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files) return;
    const files = Array.from(e.target.files);
    setIsUploading(true);
    
    try {
      const uploadPromises = files.map(async (file) => {
        const { file_url } = await base44.integrations.Core.UploadFile({ file: file as any });
        return file_url;
      });
      
      const uploadedUrls = await Promise.all(uploadPromises);
      setPhotos([...photos, ...uploadedUrls]);
    } catch (error) {
      console.error('Upload failed:', error);
    }
    
    setIsUploading(false);
  };

  const removePhoto = (index: number) => {
    setPhotos(photos.filter((_, i) => i !== index));
  };

  const createMutation = useMutation({
    mutationFn: async (data: any) => {
      return await base44.entities.Distribution.create(data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['my-distributions'] });
      setSubmitted(true);
    }
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    const distributionData = {
      ...formData,
      beneficiary_count: parseInt(formData.beneficiary_count),
      items_distributed: parseInt(formData.items_distributed),
      field_officer_id: user?.id,
      field_officer_name: user?.name,
      gps_latitude: gpsLocation?.latitude,
      gps_longitude: gpsLocation?.longitude,
      photo_urls: photos,
      status: 'pending'
    };

    createMutation.mutate(distributionData);
    setIsSubmitting(false);
  };

  if (submitted) {
    return (
      <div className="min-h-screen bg-gray-100 flex items-center justify-center p-4">
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="bg-white rounded-3xl p-8 shadow-xl text-center max-w-md"
        >
          <div className="w-20 h-20 rounded-full bg-emerald-100 flex items-center justify-center mx-auto mb-6">
            <Check className="w-10 h-10 text-emerald-600" />
          </div>
          <h1 className="text-2xl font-bold text-gray-900 mb-2">
            Distribution Submitted!
          </h1>
          <p className="text-gray-600 mb-6">
            Your distribution report has been submitted for review. An admin will verify it soon.
          </p>
          <Button 
            onClick={() => {
              setSubmitted(false);
              setFormData({
                location_name: '',
                location_type: '',
                region: '',
                country: '',
                beneficiary_count: '',
                items_distributed: '',
                distribution_date: new Date().toISOString().split('T')[0],
                notes: ''
              });
              setPhotos([]);
              setGpsLocation(null);
            }}
            className="bg-gradient-to-r from-rose-500 to-amber-500"
          >
            <Plus className="w-4 h-4 mr-2" />
            Submit Another
          </Button>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <header className="bg-gradient-to-r from-rose-600 to-amber-600 text-white p-6">
        <div className="max-w-2xl mx-auto">
          <h1 className="text-2xl font-bold mb-1">Field Officer Portal</h1>
          <p className="text-white/80">Report distributions and upload verification</p>
        </div>
      </header>

      <div className="max-w-2xl mx-auto p-4 -mt-6">
        <Card className="shadow-xl">
          <CardHeader>
            <CardTitle>New Distribution Report</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* GPS Location */}
              <div>
                <Label className="mb-2 block">GPS Location *</Label>
                {gpsLocation ? (
                  <div className="flex items-center gap-2 p-3 bg-emerald-50 rounded-lg text-emerald-700">
                    <MapPin className="w-5 h-5" />
                    <span className="text-sm">
                      {gpsLocation.latitude.toFixed(6)}, {gpsLocation.longitude.toFixed(6)}
                    </span>
                    <Check className="w-4 h-4 ml-auto" />
                  </div>
                ) : (
                  <div>
                    <Button
                      type="button"
                      variant="outline"
                      onClick={getGPSLocation}
                      className="w-full"
                    >
                      <MapPin className="w-4 h-4 mr-2" />
                      Capture GPS Location
                    </Button>
                    {gpsError && (
                      <p className="text-red-500 text-sm mt-2">{gpsError}</p>
                    )}
                  </div>
                )}
              </div>

              {/* Location Details */}
              <div className="grid grid-cols-2 gap-4">
                <div className="col-span-2">
                  <Label className="mb-2 block">Location Name *</Label>
                  <Input
                    required
                    placeholder="e.g., Government Girls Secondary School"
                    value={formData.location_name}
                    onChange={(e) => setFormData({ ...formData, location_name: e.target.value })}
                  />
                </div>
                <div>
                  <Label className="mb-2 block">Location Type *</Label>
                  <Select 
                    value={formData.location_type} 
                    onValueChange={(v: string) => setFormData({ ...formData, location_type: v })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="school">School</SelectItem>
                      <SelectItem value="community">Community</SelectItem>
                      <SelectItem value="health_center">Health Center</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="mb-2 block">Distribution Date *</Label>
                  <Input
                    type="date"
                    required
                    value={formData.distribution_date}
                    onChange={(e) => setFormData({ ...formData, distribution_date: e.target.value })}
                  />
                </div>
                <div>
                  <Label className="mb-2 block">Region *</Label>
                  <Input
                    required
                    placeholder="e.g., Lagos State"
                    value={formData.region}
                    onChange={(e) => setFormData({ ...formData, region: e.target.value })}
                  />
                </div>
                <div>
                  <Label className="mb-2 block">Country *</Label>
                  <Input
                    required
                    placeholder="e.g., Nigeria"
                    value={formData.country}
                    onChange={(e) => setFormData({ ...formData, country: e.target.value })}
                  />
                </div>
              </div>

              {/* Beneficiary Info */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="mb-2 block">Number of Beneficiaries *</Label>
                  <Input
                    type="number"
                    required
                    min="1"
                    placeholder="e.g., 100"
                    value={formData.beneficiary_count}
                    onChange={(e) => setFormData({ ...formData, beneficiary_count: e.target.value })}
                  />
                </div>
                <div>
                  <Label className="mb-2 block">Items Distributed *</Label>
                  <Input
                    type="number"
                    required
                    min="1"
                    placeholder="e.g., 500"
                    value={formData.items_distributed}
                    onChange={(e) => setFormData({ ...formData, items_distributed: e.target.value })}
                  />
                </div>
              </div>

              {/* Photo Upload */}
              <div>
                <Label className="mb-2 block">Distribution Photos *</Label>
                <div className="border-2 border-dashed border-gray-300 rounded-xl p-6">
                  {photos.length > 0 && (
                    <div className="grid grid-cols-3 gap-3 mb-4">
                      {photos.map((url, index) => (
                        <div key={index} className="relative aspect-square">
                          <img 
                            src={url} 
                            alt={`Photo ${index + 1}`}
                            className="w-full h-full object-cover rounded-lg"
                          />
                          <button
                            type="button"
                            onClick={() => removePhoto(index)}
                            className="absolute -top-2 -right-2 w-6 h-6 bg-red-500 text-white rounded-full flex items-center justify-center"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                  <input
                    type="file"
                    accept="image/*"
                    multiple
                    // capture="environment" // Can cause issues on desktop
                    onChange={handlePhotoUpload}
                    className="hidden"
                    id="photo-upload"
                    disabled={isUploading}
                  />
                  <label 
                    htmlFor="photo-upload" 
                    className="cursor-pointer flex flex-col items-center text-gray-500"
                  >
                    {isUploading ? (
                      <Loader2 className="w-8 h-8 animate-spin" />
                    ) : (
                      <Camera className="w-8 h-8 mb-2" />
                    )}
                    <span className="font-medium">
                      {isUploading ? 'Uploading...' : 'Tap to take or upload photos'}
                    </span>
                    <span className="text-sm">Minimum 2 photos required</span>
                  </label>
                </div>
              </div>

              {/* Notes */}
              <div>
                <Label className="mb-2 block">Additional Notes</Label>
                <Textarea
                  placeholder="Any additional information about the distribution..."
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  rows={3}
                />
              </div>

              {/* Submit */}
              <Button
                type="submit"
                className="w-full bg-gradient-to-r from-rose-500 to-amber-500 py-6"
                disabled={isSubmitting || photos.length < 2 || !gpsLocation}
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                    Submitting...
                  </>
                ) : (
                  <>
                    <Upload className="w-5 h-5 mr-2" />
                    Submit Distribution Report
                  </>
                )}
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Recent Submissions */}
        {myDistributions.length > 0 && (
          <Card className="mt-6">
            <CardHeader>
              <CardTitle className="text-lg">Recent Submissions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {myDistributions.slice(0, 5).map((dist: any) => (
                <div key={dist.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div>
                    <p className="font-medium text-gray-900">{dist.location_name}</p>
                    <p className="text-sm text-gray-500">
                      {dist.beneficiary_count} beneficiaries • {format(new Date(dist.distribution_date || dist.created_at), 'MMM d, yyyy')}
                    </p>
                  </div>
                  <Badge 
                    variant="secondary"
                    className={
                      dist.status === 'approved' ? 'bg-emerald-100 text-emerald-700' :
                      dist.status === 'pending' ? 'bg-amber-100 text-amber-700' :
                      'bg-red-100 text-red-700'
                    }
                  >
                    {dist.status}
                  </Badge>
                </div>
              ))}
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}