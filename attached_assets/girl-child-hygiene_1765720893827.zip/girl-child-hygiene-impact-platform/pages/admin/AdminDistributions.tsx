import React, { useState, useEffect } from 'react';
import { base44 } from '@/services/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { format } from 'date-fns';
import { 
  Search, Download, Eye, Check, X,
  MapPin, Image, Calendar, Users
} from 'lucide-react';
import AdminSidebar from '@/components/admin/AdminSidebar';
import AdminHeader from '@/components/admin/AdminHeader';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';

export default function AdminDistributions() {
  const [user, setUser] = useState<any>(null);
  const [statusFilter, setStatusFilter] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDistribution, setSelectedDistribution] = useState<any>(null);
  const [rejectReason, setRejectReason] = useState('');

  const queryClient = useQueryClient();

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const { data: distributions = [] } = useQuery({
    queryKey: ['admin-distributions'],
    queryFn: () => base44.entities.Distribution.list('-created_at', 200),
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: any) => {
      return await base44.entities.Distribution.update(id, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-distributions'] });
      setSelectedDistribution(null);
      setRejectReason('');
    },
  });

  const handleApprove = (distribution: any) => {
    updateMutation.mutate({
      id: distribution.id,
      data: {
        status: 'approved',
        approved_by: user?.email,
        approved_at: new Date().toISOString()
      }
    });
  };

  const handleReject = (distribution: any) => {
    updateMutation.mutate({
      id: distribution.id,
      data: {
        status: 'rejected',
        approved_by: user?.email,
        approved_at: new Date().toISOString(),
        rejection_reason: rejectReason
      }
    });
  };

  const filteredDistributions = distributions.filter((d: any) => {
    const matchesStatus = statusFilter === 'all' || d.status === statusFilter;
    const matchesSearch = 
      d.location_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      d.field_officer_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      d.region?.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesStatus && matchesSearch;
  });

  const getStatusBadge = (status: string) => {
    const styles: any = {
      approved: 'bg-emerald-100 text-emerald-700',
      pending: 'bg-amber-100 text-amber-700',
      rejected: 'bg-red-100 text-red-700',
    };
    return <Badge variant="secondary" className={styles[status]}>{status}</Badge>;
  };

  return (
    <div className="flex min-h-screen bg-gray-100">
      <AdminSidebar user={user} />
      
      <main className="flex-1">
        <AdminHeader 
          title="Distribution Management" 
          subtitle="Review and approve field officer submissions"
        />
        
        <div className="p-6">
          {/* Filters */}
          <div className="flex flex-wrap gap-4 mb-6">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input
                placeholder="Search by location, officer, or region..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9"
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="approved">Approved</SelectItem>
                <SelectItem value="rejected">Rejected</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline">
              <Download className="w-4 h-4 mr-2" />
              Export
            </Button>
          </div>

          {/* Distributions Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredDistributions.map((dist: any) => (
              <Card key={dist.id} className="overflow-hidden">
                <div className="aspect-video relative bg-gray-200">
                  {dist.photo_urls?.[0] ? (
                    <img 
                      src={dist.photo_urls[0]} 
                      alt={dist.location_name}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-gray-400">
                      <Image className="w-12 h-12" />
                    </div>
                  )}
                  <div className="absolute top-2 right-2">
                    {getStatusBadge(dist.status)}
                  </div>
                  {dist.photo_urls?.length > 1 && (
                    <div className="absolute bottom-2 right-2 bg-black/50 text-white text-xs px-2 py-1 rounded">
                      +{dist.photo_urls.length - 1} more
                    </div>
                  )}
                </div>
                <CardContent className="p-4">
                  <h3 className="font-bold text-gray-900 mb-1">{dist.location_name}</h3>
                  <div className="space-y-2 text-sm text-gray-500">
                    <div className="flex items-center gap-2">
                      <MapPin className="w-4 h-4" />
                      {dist.region}, {dist.country}
                    </div>
                    <div className="flex items-center gap-2">
                      <Users className="w-4 h-4" />
                      {dist.beneficiary_count} beneficiaries
                    </div>
                    <div className="flex items-center gap-2">
                      <Calendar className="w-4 h-4" />
                      {format(new Date(dist.distribution_date || dist.created_at || Date.now()), 'MMM d, yyyy')}
                    </div>
                  </div>
                  <div className="flex gap-2 mt-4">
                    <Button
                      variant="outline"
                      size="sm"
                      className="flex-1"
                      onClick={() => setSelectedDistribution(dist)}
                    >
                      <Eye className="w-4 h-4 mr-1" />
                      View
                    </Button>
                    {dist.status === 'pending' && (
                      <>
                        <Button
                          size="sm"
                          className="bg-emerald-600 hover:bg-emerald-700"
                          onClick={() => handleApprove(dist)}
                        >
                          <Check className="w-4 h-4" />
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          className="text-red-600"
                          onClick={() => setSelectedDistribution(dist)}
                        >
                          <X className="w-4 h-4" />
                        </Button>
                      </>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {filteredDistributions.length === 0 && (
            <div className="text-center py-12 text-gray-500">
              No distributions found.
            </div>
          )}
        </div>

        {/* Distribution Detail Modal */}
        <Dialog open={!!selectedDistribution} onOpenChange={() => setSelectedDistribution(null)}>
          <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Distribution Details</DialogTitle>
            </DialogHeader>
            
            {selectedDistribution && (
              <div className="space-y-6">
                {/* Photos */}
                {selectedDistribution.photo_urls?.length > 0 && (
                  <div>
                    <p className="text-sm text-gray-500 mb-2">Photos</p>
                    <div className="grid grid-cols-3 gap-2">
                      {selectedDistribution.photo_urls.map((url: string, idx: number) => (
                        <img 
                          key={idx}
                          src={url}
                          alt={`Distribution photo ${idx + 1}`}
                          className="rounded-lg object-cover aspect-square"
                        />
                      ))}
                    </div>
                  </div>
                )}

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-gray-500">Location</p>
                    <p className="font-medium">{selectedDistribution.location_name}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Region</p>
                    <p className="font-medium">{selectedDistribution.region}, {selectedDistribution.country}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Beneficiaries</p>
                    <p className="font-medium">{selectedDistribution.beneficiary_count}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Items Distributed</p>
                    <p className="font-medium">{selectedDistribution.items_distributed}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Field Officer</p>
                    <p className="font-medium">{selectedDistribution.field_officer_name}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Date</p>
                    <p className="font-medium">
                      {format(new Date(selectedDistribution.distribution_date || selectedDistribution.created_at || Date.now()), 'MMM d, yyyy')}
                    </p>
                  </div>
                  {selectedDistribution.gps_latitude && selectedDistribution.gps_longitude && (
                    <div className="col-span-2">
                      <p className="text-sm text-gray-500">GPS Coordinates</p>
                      <p className="font-medium">
                        {selectedDistribution.gps_latitude}, {selectedDistribution.gps_longitude}
                      </p>
                    </div>
                  )}
                </div>

                {selectedDistribution.status === 'pending' && (
                  <div>
                    <p className="text-sm text-gray-500 mb-2">Rejection Reason (if rejecting)</p>
                    <Textarea
                      placeholder="Enter reason for rejection..."
                      value={rejectReason}
                      onChange={(e) => setRejectReason(e.target.value)}
                    />
                  </div>
                )}
              </div>
            )}

            <DialogFooter>
              {selectedDistribution?.status === 'pending' && (
                <>
                  <Button
                    variant="outline"
                    onClick={() => handleReject(selectedDistribution)}
                    className="text-red-600"
                    disabled={!rejectReason}
                  >
                    <X className="w-4 h-4 mr-2" />
                    Reject
                  </Button>
                  <Button
                    onClick={() => handleApprove(selectedDistribution)}
                    className="bg-emerald-600 hover:bg-emerald-700"
                  >
                    <Check className="w-4 h-4 mr-2" />
                    Approve
                  </Button>
                </>
              )}
              <Button variant="outline" onClick={() => setSelectedDistribution(null)}>
                Close
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </main>
    </div>
  );
}