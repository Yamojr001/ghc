import React, { useState, useEffect } from 'react';
import { base44 } from '@/services/base44Client';
import { useQuery } from '@tanstack/react-query';
import { 
  Download, BarChart3, PieChart, TrendingUp, Calendar
} from 'lucide-react';
import AdminSidebar from '@/components/admin/AdminSidebar';
import AdminHeader from '@/components/admin/AdminHeader';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, 
  Tooltip, ResponsiveContainer, PieChart as RechartsPie, 
  Pie, Cell
} from 'recharts';

const COLORS = ['#f43f5e', '#f59e0b', '#10b981', '#3b82f6', '#8b5cf6'];

export default function AdminReports() {
  const [user, setUser] = useState<any>(null);
  const [dateRange, setDateRange] = useState('all');

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const { data: donations = [] } = useQuery({
    queryKey: ['report-donations'],
    queryFn: () => base44.entities.Donation.filter({ status: 'verified' }, '-created_at'),
  });

  const { data: expenses = [] } = useQuery({
    queryKey: ['report-expenses'],
    queryFn: () => base44.entities.Expense.filter({ status: 'approved' }, '-created_at'),
  });

  const { data: distributions = [] } = useQuery({
    queryKey: ['report-distributions'],
    queryFn: () => base44.entities.Distribution.filter({ status: 'approved' }, '-created_at'),
  });

  // Calculate summaries
  const totalIncome = donations.reduce((acc: number, d: any) => acc + (d.amount_usd || 0), 0);
  const totalExpenses = expenses.reduce((acc: number, e: any) => acc + (e.amount_usd || 0), 0);
  const netBalance = totalIncome - totalExpenses;
  const totalBeneficiaries = distributions.reduce((acc: number, d: any) => acc + (d.beneficiary_count || 0), 0);

  // Donations by category
  const donationsByCategory = donations.reduce((acc: any, d: any) => {
    const category = d.category || 'other';
    acc[category] = (acc[category] || 0) + (d.amount_usd || 0);
    return acc;
  }, {});

  const categoryData = Object.entries(donationsByCategory).map(([name, value]) => ({
    name: name.charAt(0).toUpperCase() + name.slice(1),
    value
  }));

  // Expenses by category
  const expensesByCategory = expenses.reduce((acc: any, e: any) => {
    const category = e.category || 'other';
    acc[category] = (acc[category] || 0) + (e.amount_usd || 0);
    return acc;
  }, {});

  const expenseCategoryData = Object.entries(expensesByCategory).map(([name, value]) => ({
    name: name.replace('_', ' ').charAt(0).toUpperCase() + name.replace('_', ' ').slice(1),
    value
  }));

  // Monthly data
  const monthlyData = donations.reduce((acc: any, d: any) => {
    const month = new Date(d.created_date || d.created_at).toLocaleString('default', { month: 'short' });
    acc[month] = (acc[month] || 0) + (d.amount_usd || 0);
    return acc;
  }, {});

  const monthlyChartData = Object.entries(monthlyData).slice(-6).map(([month, amount]) => ({
    month,
    amount
  }));

  return (
    <div className="flex min-h-screen bg-gray-100">
      <AdminSidebar user={user} />
      
      <main className="flex-1">
        <AdminHeader 
          title="Reports & Analytics" 
          subtitle="Financial reports and impact analytics"
        />
        
        <div className="p-6">
          {/* Controls */}
          <div className="flex justify-between items-center mb-6">
            <Select value={dateRange} onValueChange={setDateRange}>
              <SelectTrigger className="w-40">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Time</SelectItem>
                <SelectItem value="year">This Year</SelectItem>
                <SelectItem value="quarter">This Quarter</SelectItem>
                <SelectItem value="month">This Month</SelectItem>
              </SelectContent>
            </Select>
            <div className="flex gap-2">
              <Button variant="outline">
                <Download className="w-4 h-4 mr-2" />
                Export PDF
              </Button>
              <Button variant="outline">
                <Download className="w-4 h-4 mr-2" />
                Export Excel
              </Button>
            </div>
          </div>

          {/* Summary Cards */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-500">Total Income</p>
                    <p className="text-2xl font-bold text-emerald-600">${totalIncome.toLocaleString()}</p>
                  </div>
                  <TrendingUp className="w-10 h-10 text-emerald-200" />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-500">Total Expenses</p>
                    <p className="text-2xl font-bold text-rose-600">${totalExpenses.toLocaleString()}</p>
                  </div>
                  <BarChart3 className="w-10 h-10 text-rose-200" />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-500">Net Balance</p>
                    <p className={`text-2xl font-bold ${netBalance >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>
                      ${netBalance.toLocaleString()}
                    </p>
                  </div>
                  <PieChart className="w-10 h-10 text-blue-200" />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-500">Beneficiaries</p>
                    <p className="text-2xl font-bold text-purple-600">{totalBeneficiaries.toLocaleString()}</p>
                  </div>
                  <Calendar className="w-10 h-10 text-purple-200" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Charts Row */}
          <div className="grid lg:grid-cols-2 gap-6 mb-8">
            {/* Monthly Donations */}
            <Card>
              <CardHeader>
                <CardTitle>Monthly Donations</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={monthlyChartData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                    <XAxis dataKey="month" stroke="#6b7280" />
                    <YAxis stroke="#6b7280" tickFormatter={(v) => `$${v / 1000}K`} />
                    <Tooltip formatter={(v: any) => `$${v.toLocaleString()}`} />
                    <Bar dataKey="amount" fill="#f43f5e" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Donations by Category */}
            <Card>
              <CardHeader>
                <CardTitle>Donations by Category</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <RechartsPie>
                    <Pie
                      data={categoryData}
                      dataKey="value"
                      nameKey="name"
                      cx="50%"
                      cy="50%"
                      outerRadius={100}
                      label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    >
                      {categoryData.map((entry: any, index: number) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(v: any) => `$${v.toLocaleString()}`} />
                  </RechartsPie>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          {/* Expense Breakdown */}
          <Card>
            <CardHeader>
              <CardTitle>Expense Breakdown by Category</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-6">
                <ResponsiveContainer width="100%" height={300}>
                  <RechartsPie>
                    <Pie
                      data={expenseCategoryData}
                      dataKey="value"
                      nameKey="name"
                      cx="50%"
                      cy="50%"
                      outerRadius={100}
                      innerRadius={50}
                    >
                      {expenseCategoryData.map((entry: any, index: number) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(v: any) => `$${v.toLocaleString()}`} />
                  </RechartsPie>
                </ResponsiveContainer>
                <div className="space-y-3">
                  {expenseCategoryData.map((item: any, index: number) => (
                    <div key={item.name} className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div 
                          className="w-4 h-4 rounded-full"
                          style={{ backgroundColor: COLORS[index % COLORS.length] }}
                        />
                        <span className="text-gray-700">{item.name}</span>
                      </div>
                      <span className="font-semibold">${item.value.toLocaleString()}</span>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}