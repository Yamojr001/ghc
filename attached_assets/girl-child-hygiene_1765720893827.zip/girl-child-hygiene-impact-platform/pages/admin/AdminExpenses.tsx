import React, { useState, useEffect } from 'react';
import { base44 } from '@/services/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { format } from 'date-fns';
import { 
  Search, Download, Plus, Check, X, Edit, DollarSign
} from 'lucide-react';
import AdminSidebar from '@/components/admin/AdminSidebar';
import AdminHeader from '@/components/admin/AdminHeader';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';

const expenseCategories = [
  { value: 'program_delivery', label: 'Program Delivery' },
  { value: 'supplies', label: 'Supplies & Materials' },
  { value: 'logistics', label: 'Logistics & Transport' },
  { value: 'staff', label: 'Staff & Salaries' },
  { value: 'admin', label: 'Administration' },
  { value: 'marketing', label: 'Marketing' },
  { value: 'training', label: 'Training' },
  { value: 'equipment', label: 'Equipment' },
  { value: 'other', label: 'Other' },
];

export default function AdminExpenses() {
  const [user, setUser] = useState<any>(null);
  const [statusFilter, setStatusFilter] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [newExpense, setNewExpense] = useState({
    title: '',
    description: '',
    category: '',
    amount: '',
    currency: 'USD',
    expense_date: new Date().toISOString().split('T')[0],
    vendor: ''
  });

  const queryClient = useQueryClient();

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const { data: expenses = [] } = useQuery({
    queryKey: ['admin-expenses'],
    queryFn: () => base44.entities.Expense.list('-created_at', 200),
  });

  const createMutation = useMutation({
    mutationFn: async (data: any) => {
      return await base44.entities.Expense.create(data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-expenses'] });
      setIsAddModalOpen(false);
      setNewExpense({
        title: '',
        description: '',
        category: '',
        amount: '',
        currency: 'USD',
        expense_date: new Date().toISOString().split('T')[0],
        vendor: ''
      });
    }
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: any) => {
      return await base44.entities.Expense.update(id, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-expenses'] });
    }
  });

  const handleApprove = (expense: any) => {
    updateMutation.mutate({
      id: expense.id,
      data: {
        status: 'approved',
        approved_by: user?.email,
        approved_at: new Date().toISOString()
      }
    });
  };

  const handleReject = (expense: any) => {
    updateMutation.mutate({
      id: expense.id,
      data: {
        status: 'rejected',
        approved_by: user?.email,
        approved_at: new Date().toISOString()
      }
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createMutation.mutate({
      ...newExpense,
      amount: parseFloat(newExpense.amount),
      amount_usd: parseFloat(newExpense.amount),
      status: 'pending'
    });
  };

  const filteredExpenses = expenses.filter((e: any) => {
    const matchesStatus = statusFilter === 'all' || e.status === statusFilter;
    const matchesSearch = 
      e.title?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      e.vendor?.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesStatus && matchesSearch;
  });

  const totalApproved = expenses
    .filter((e: any) => e.status === 'approved')
    .reduce((acc: number, e: any) => acc + (e.amount_usd || 0), 0);

  const totalPending = expenses
    .filter((e: any) => e.status === 'pending')
    .reduce((acc: number, e: any) => acc + (e.amount_usd || 0), 0);

  const getStatusBadge = (status: string) => {
    const styles: any = {
      approved: 'bg-emerald-100 text-emerald-700',
      pending: 'bg-amber-100 text-amber-700',
      rejected: 'bg-red-100 text-red-700',
    };
    return <Badge variant="secondary" className={styles[status]}>{status}</Badge>;
  };

  return (
    <div className="flex min-h-screen bg-gray-100">
      <AdminSidebar user={user} />
      
      <main className="flex-1">
        <AdminHeader 
          title="Expense Management" 
          subtitle="Track and manage organizational expenses"
        />
        
        <div className="p-6">
          {/* Stats */}
          <div className="grid grid-cols-3 gap-4 mb-6">
            <Card>
              <CardContent className="p-4 text-center">
                <p className="text-3xl font-bold text-emerald-600">${totalApproved.toLocaleString()}</p>
                <p className="text-sm text-gray-500">Total Approved</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4 text-center">
                <p className="text-3xl font-bold text-amber-600">${totalPending.toLocaleString()}</p>
                <p className="text-sm text-gray-500">Pending Approval</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4 text-center">
                <p className="text-3xl font-bold text-gray-600">{expenses.length}</p>
                <p className="text-sm text-gray-500">Total Expenses</p>
              </CardContent>
            </Card>
          </div>

          {/* Filters */}
          <div className="flex flex-wrap gap-4 mb-6">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input
                placeholder="Search expenses..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9"
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="approved">Approved</SelectItem>
                <SelectItem value="rejected">Rejected</SelectItem>
              </SelectContent>
            </Select>
            <Button onClick={() => setIsAddModalOpen(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Add Expense
            </Button>
            <Button variant="outline">
              <Download className="w-4 h-4 mr-2" />
              Export
            </Button>
          </div>

          {/* Expenses Table */}
          <Card>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50 border-b">
                    <tr>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Title</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Category</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Amount</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Date</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y">
                    {filteredExpenses.map((expense: any) => (
                      <tr key={expense.id} className="hover:bg-gray-50">
                        <td className="px-4 py-4">
                          <div>
                            <p className="font-medium text-gray-900">{expense.title}</p>
                            <p className="text-sm text-gray-500">{expense.vendor}</p>
                          </div>
                        </td>
                        <td className="px-4 py-4">
                          <span className="capitalize text-gray-700">{expense.category?.replace('_', ' ')}</span>
                        </td>
                        <td className="px-4 py-4">
                          <p className="font-bold text-gray-900">${expense.amount_usd?.toFixed(2)}</p>
                        </td>
                        <td className="px-4 py-4">
                          <p className="text-gray-700">
                            {format(new Date(expense.expense_date || expense.created_at || Date.now()), 'MMM d, yyyy')}
                          </p>
                        </td>
                        <td className="px-4 py-4">
                          {getStatusBadge(expense.status)}
                        </td>
                        <td className="px-4 py-4">
                          <div className="flex items-center gap-2">
                            {expense.status === 'pending' && (
                              <>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="text-emerald-600 hover:text-emerald-700 hover:bg-emerald-50"
                                  onClick={() => handleApprove(expense)}
                                >
                                  <Check className="w-4 h-4" />
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="text-red-600 hover:text-red-700 hover:bg-red-50"
                                  onClick={() => handleReject(expense)}
                                >
                                  <X className="w-4 h-4" />
                                </Button>
                              </>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Add Expense Modal */}
        <Dialog open={isAddModalOpen} onOpenChange={setIsAddModalOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add New Expense</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label>Title *</Label>
                <Input
                  required
                  value={newExpense.title}
                  onChange={(e) => setNewExpense({ ...newExpense, title: e.target.value })}
                  placeholder="Expense title"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Category *</Label>
                  <Select
                    value={newExpense.category}
                    onValueChange={(v: string) => setNewExpense({ ...newExpense, category: v })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      {expenseCategories.map((cat) => (
                        <SelectItem key={cat.value} value={cat.value}>{cat.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Amount (USD) *</Label>
                  <Input
                    type="number"
                    required
                    min="0"
                    step="0.01"
                    value={newExpense.amount}
                    onChange={(e) => setNewExpense({ ...newExpense, amount: e.target.value })}
                    placeholder="0.00"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Date *</Label>
                  <Input
                    type="date"
                    required
                    value={newExpense.expense_date}
                    onChange={(e) => setNewExpense({ ...newExpense, expense_date: e.target.value })}
                  />
                </div>
                <div>
                  <Label>Vendor</Label>
                  <Input
                    value={newExpense.vendor}
                    onChange={(e) => setNewExpense({ ...newExpense, vendor: e.target.value })}
                    placeholder="Vendor name"
                  />
                </div>
              </div>
              <div>
                <Label>Description</Label>
                <Textarea
                  value={newExpense.description}
                  onChange={(e) => setNewExpense({ ...newExpense, description: e.target.value })}
                  placeholder="Additional details..."
                  rows={3}
                />
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsAddModalOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" disabled={createMutation.isPending}>
                  Add Expense
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </main>
    </div>
  );
}