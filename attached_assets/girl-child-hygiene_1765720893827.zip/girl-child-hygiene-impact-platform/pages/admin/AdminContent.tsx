import React, { useState, useEffect } from 'react';
import { base44 } from '@/services/base44Client';
import { useQuery } from '@tanstack/react-query';
import { 
  FileText, Image, Users, MessageSquare, Star
} from 'lucide-react';
import AdminSidebar from '@/components/admin/AdminSidebar';
import AdminHeader from '@/components/admin/AdminHeader';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { format } from 'date-fns';

export default function AdminContent() {
  const [user, setUser] = useState<any>(null);

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const { data: blogPosts = [] } = useQuery({
    queryKey: ['blog-posts-all'],
    queryFn: () => base44.entities.BlogPost.list('-created_at'),
  });

  const { data: testimonials = [] } = useQuery({
    queryKey: ['testimonials-all'],
    queryFn: () => base44.entities.Testimonial.list('-created_at'),
  });

  const { data: gallery = [] } = useQuery({
    queryKey: ['gallery-all'],
    queryFn: () => base44.entities.GalleryItem.list('-created_at'),
  });

  const { data: contacts = [] } = useQuery({
    queryKey: ['contacts-all'],
    queryFn: () => base44.entities.ContactMessage.list('-created_at'),
  });

  const { data: subscribers = [] } = useQuery({
    queryKey: ['subscribers-all'],
    queryFn: () => base44.entities.Subscriber.list('-created_at'),
  });

  return (
    <div className="flex min-h-screen bg-gray-100">
      <AdminSidebar user={user} />
      
      <main className="flex-1">
        <AdminHeader 
          title="Content Management" 
          subtitle="Manage blog posts, gallery, testimonials, and more"
        />
        
        <div className="p-6">
          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-6">
            <Card>
              <CardContent className="p-4 text-center">
                <FileText className="w-8 h-8 text-blue-500 mx-auto mb-2" />
                <p className="text-2xl font-bold text-gray-900">{blogPosts.length}</p>
                <p className="text-xs text-gray-500">Blog Posts</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4 text-center">
                <Image className="w-8 h-8 text-purple-500 mx-auto mb-2" />
                <p className="text-2xl font-bold text-gray-900">{gallery.length}</p>
                <p className="text-xs text-gray-500">Gallery Items</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4 text-center">
                <Star className="w-8 h-8 text-amber-500 mx-auto mb-2" />
                <p className="text-2xl font-bold text-gray-900">{testimonials.length}</p>
                <p className="text-xs text-gray-500">Testimonials</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4 text-center">
                <MessageSquare className="w-8 h-8 text-rose-500 mx-auto mb-2" />
                <p className="text-2xl font-bold text-gray-900">{contacts.length}</p>
                <p className="text-xs text-gray-500">Messages</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4 text-center">
                <Users className="w-8 h-8 text-emerald-500 mx-auto mb-2" />
                <p className="text-2xl font-bold text-gray-900">{subscribers.length}</p>
                <p className="text-xs text-gray-500">Subscribers</p>
              </CardContent>
            </Card>
          </div>

          <Tabs defaultValue="posts">
            <TabsList className="mb-6">
              <TabsTrigger value="posts">Blog Posts</TabsTrigger>
              <TabsTrigger value="testimonials">Testimonials</TabsTrigger>
              <TabsTrigger value="messages">Messages</TabsTrigger>
              <TabsTrigger value="subscribers">Subscribers</TabsTrigger>
            </TabsList>

            <TabsContent value="posts">
              <Card>
                <CardContent className="p-0">
                  <div className="divide-y">
                    {blogPosts.map((post: any) => (
                      <div key={post.id} className="p-4 flex items-center justify-between hover:bg-gray-50">
                        <div className="flex items-center gap-4">
                          {post.featured_image && (
                            <img 
                              src={post.featured_image} 
                              alt={post.title}
                              className="w-16 h-12 object-cover rounded"
                            />
                          )}
                          <div>
                            <p className="font-medium text-gray-900">{post.title}</p>
                            <p className="text-sm text-gray-500">{post.author_name}</p>
                          </div>
                        </div>
                        <Badge variant="secondary" className={
                          post.status === 'published' ? 'bg-emerald-100 text-emerald-700' : 'bg-gray-100 text-gray-700'
                        }>
                          {post.status}
                        </Badge>
                      </div>
                    ))}
                    {blogPosts.length === 0 && (
                      <p className="p-8 text-center text-gray-500">No blog posts yet.</p>
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="testimonials">
              <Card>
                <CardContent className="p-0">
                  <div className="divide-y">
                    {testimonials.map((t: any) => (
                      <div key={t.id} className="p-4 hover:bg-gray-50">
                        <div className="flex items-start gap-4">
                          {t.image_url && (
                            <img 
                              src={t.image_url} 
                              alt={t.name}
                              className="w-12 h-12 object-cover rounded-full"
                            />
                          )}
                          <div className="flex-1">
                            <div className="flex items-center justify-between mb-1">
                              <p className="font-medium text-gray-900">{t.name}</p>
                              <Badge variant="secondary" className={
                                t.is_approved ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'
                              }>
                                {t.is_approved ? 'Approved' : 'Pending'}
                              </Badge>
                            </div>
                            <p className="text-sm text-gray-500 mb-2">{t.role}</p>
                            <p className="text-gray-600 italic">"{t.quote}"</p>
                          </div>
                        </div>
                      </div>
                    ))}
                    {testimonials.length === 0 && (
                      <p className="p-8 text-center text-gray-500">No testimonials yet.</p>
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="messages">
              <Card>
                <CardContent className="p-0">
                  <div className="divide-y">
                    {contacts.map((msg: any) => (
                      <div key={msg.id} className="p-4 hover:bg-gray-50">
                        <div className="flex items-start justify-between">
                          <div>
                            <p className="font-medium text-gray-900">{msg.subject}</p>
                            <p className="text-sm text-gray-500">{msg.name} • {msg.email}</p>
                            <p className="text-gray-600 mt-2 line-clamp-2">{msg.message}</p>
                          </div>
                          <div className="text-right">
                            <Badge variant="secondary" className={
                              msg.status === 'resolved' ? 'bg-emerald-100 text-emerald-700' :
                              msg.status === 'in_progress' ? 'bg-blue-100 text-blue-700' :
                              'bg-amber-100 text-amber-700'
                            }>
                              {msg.status}
                            </Badge>
                            <p className="text-xs text-gray-500 mt-1">
                              {format(new Date(msg.created_date || msg.created_at || Date.now()), 'MMM d, yyyy')}
                            </p>
                          </div>
                        </div>
                      </div>
                    ))}
                    {contacts.length === 0 && (
                      <p className="p-8 text-center text-gray-500">No messages yet.</p>
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="subscribers">
              <Card>
                <CardContent className="p-0">
                  <div className="divide-y">
                    {subscribers.map((sub: any) => (
                      <div key={sub.id} className="p-4 flex items-center justify-between hover:bg-gray-50">
                        <div>
                          <p className="font-medium text-gray-900">{sub.email}</p>
                          <p className="text-sm text-gray-500">Source: {sub.source}</p>
                        </div>
                        <div className="text-right">
                          <Badge variant="secondary" className={
                            sub.status === 'active' ? 'bg-emerald-100 text-emerald-700' : 'bg-gray-100 text-gray-700'
                          }>
                            {sub.status}
                          </Badge>
                          <p className="text-xs text-gray-500 mt-1">
                            {format(new Date(sub.created_date || sub.created_at || Date.now()), 'MMM d, yyyy')}
                          </p>
                        </div>
                      </div>
                    ))}
                    {subscribers.length === 0 && (
                      <p className="p-8 text-center text-gray-500">No subscribers yet.</p>
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  );
}