import React, { useState, useEffect } from 'react';
import { base44 } from '@/services/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { format } from 'date-fns';
import { 
  Search, Download, Eye, Check, X,
  ExternalLink
} from 'lucide-react';
import AdminSidebar from '@/components/admin/AdminSidebar';
import AdminHeader from '@/components/admin/AdminHeader';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';

export default function AdminDonations() {
  const [user, setUser] = useState<any>(null);
  const [statusFilter, setStatusFilter] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDonation, setSelectedDonation] = useState<any>(null);
  const [rejectReason, setRejectReason] = useState('');

  const queryClient = useQueryClient();

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const { data: donations = [] } = useQuery({
    queryKey: ['admin-donations'],
    queryFn: () => base44.entities.Donation.list('-created_at', 200),
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: any) => {
      return await base44.entities.Donation.update(id, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-donations'] });
      setSelectedDonation(null);
    },
  });

  const handleVerify = (donation: any) => {
    updateMutation.mutate({
      id: donation.id,
      data: {
        status: 'verified',
        verified_by: user?.email,
        verified_at: new Date().toISOString()
      }
    });
  };

  const handleReject = (donation: any) => {
    updateMutation.mutate({
      id: donation.id,
      data: {
        status: 'rejected',
        verified_by: user?.email,
        verified_at: new Date().toISOString(),
        notes: rejectReason
      }
    });
    setRejectReason('');
  };

  const filteredDonations = donations.filter((d: any) => {
    const matchesStatus = statusFilter === 'all' || d.status === statusFilter;
    const matchesSearch = 
      d.donor_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      d.donor_email?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      d.payment_reference?.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesStatus && matchesSearch;
  });

  const getStatusBadge = (status: string) => {
    const styles: any = {
      verified: 'bg-emerald-100 text-emerald-700',
      pending: 'bg-amber-100 text-amber-700',
      rejected: 'bg-red-100 text-red-700',
      refunded: 'bg-gray-100 text-gray-700'
    };
    return <Badge variant="secondary" className={styles[status]}>{status}</Badge>;
  };

  const stats = [
    { label: 'Total Verified', value: donations.filter((d: any) => d.status === 'verified').length, color: 'text-emerald-600' },
    { label: 'Pending', value: donations.filter((d: any) => d.status === 'pending').length, color: 'text-amber-600' },
    { label: 'Rejected', value: donations.filter((d: any) => d.status === 'rejected').length, color: 'text-red-600' },
  ];

  return (
    <div className="flex min-h-screen bg-gray-100">
      <AdminSidebar user={user} />
      
      <main className="flex-1">
        <AdminHeader 
          title="Donation Management" 
          subtitle="Review, verify, and manage all donations"
        />
        
        <div className="p-6">
          {/* Stats */}
          <div className="grid grid-cols-3 gap-4 mb-6">
            {stats.map((stat) => (
              <Card key={stat.label}>
                <CardContent className="p-4 text-center">
                  <p className={`text-3xl font-bold ${stat.color}`}>{stat.value}</p>
                  <p className="text-sm text-gray-500">{stat.label}</p>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Filters */}
          <div className="flex flex-wrap gap-4 mb-6">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input
                placeholder="Search by name, email, or reference..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9"
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="verified">Verified</SelectItem>
                <SelectItem value="rejected">Rejected</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline">
              <Download className="w-4 h-4 mr-2" />
              Export
            </Button>
          </div>

          {/* Donations Table */}
          <Card>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50 border-b">
                    <tr>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Donor</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Amount</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Method</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Date</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y">
                    {filteredDonations.map((donation: any) => (
                      <tr key={donation.id} className="hover:bg-gray-50">
                        <td className="px-4 py-4">
                          <div>
                            <p className="font-medium text-gray-900">
                              {donation.is_anonymous ? 'Anonymous' : donation.donor_name}
                            </p>
                            <p className="text-sm text-gray-500">{donation.donor_email}</p>
                          </div>
                        </td>
                        <td className="px-4 py-4">
                          <p className="font-bold text-gray-900">${donation.amount_usd?.toFixed(2)}</p>
                          <p className="text-xs text-gray-500">{donation.currency}</p>
                        </td>
                        <td className="px-4 py-4">
                          <p className="text-gray-700 capitalize">{donation.payment_method?.replace('_', ' ')}</p>
                        </td>
                        <td className="px-4 py-4">
                          <p className="text-gray-700">
                            {format(new Date(donation.created_date || donation.created_at || Date.now()), 'MMM d, yyyy')}
                          </p>
                          <p className="text-xs text-gray-500">
                            {format(new Date(donation.created_date || donation.created_at || Date.now()), 'h:mm a')}
                          </p>
                        </td>
                        <td className="px-4 py-4">
                          {getStatusBadge(donation.status)}
                        </td>
                        <td className="px-4 py-4">
                          <div className="flex items-center gap-2">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => setSelectedDonation(donation)}
                            >
                              <Eye className="w-4 h-4" />
                            </Button>
                            {donation.status === 'pending' && (
                              <>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="text-emerald-600 hover:text-emerald-700 hover:bg-emerald-50"
                                  onClick={() => handleVerify(donation)}
                                >
                                  <Check className="w-4 h-4" />
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="text-red-600 hover:text-red-700 hover:bg-red-50"
                                  onClick={() => {
                                    setSelectedDonation(donation);
                                  }}
                                >
                                  <X className="w-4 h-4" />
                                </Button>
                              </>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Donation Detail Modal */}
        <Dialog open={!!selectedDonation} onOpenChange={() => setSelectedDonation(null)}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Donation Details</DialogTitle>
              <DialogDescription>
                Review donation information and take action
              </DialogDescription>
            </DialogHeader>
            
            {selectedDonation && (
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-gray-500">Donor</p>
                    <p className="font-medium">
                      {selectedDonation.is_anonymous ? 'Anonymous' : selectedDonation.donor_name}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Email</p>
                    <p className="font-medium">{selectedDonation.donor_email}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Amount</p>
                    <p className="font-bold text-lg">
                      ${selectedDonation.amount_usd?.toFixed(2)} USD
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Status</p>
                    {getStatusBadge(selectedDonation.status)}
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Payment Method</p>
                    <p className="font-medium capitalize">{selectedDonation.payment_method?.replace('_', ' ')}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Category</p>
                    <p className="font-medium capitalize">{selectedDonation.category}</p>
                  </div>
                </div>

                {selectedDonation.bank_proof_url && (
                  <div>
                    <p className="text-sm text-gray-500 mb-2">Payment Proof</p>
                    <a
                      href={selectedDonation.bank_proof_url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 text-blue-600 hover:text-blue-700"
                    >
                      <ExternalLink className="w-4 h-4" />
                      View Uploaded Proof
                    </a>
                  </div>
                )}

                {selectedDonation.message && (
                  <div>
                    <p className="text-sm text-gray-500">Donor Message</p>
                    <p className="bg-gray-50 p-3 rounded-lg mt-1">{selectedDonation.message}</p>
                  </div>
                )}

                {selectedDonation.status === 'pending' && (
                  <div>
                    <p className="text-sm text-gray-500 mb-2">Rejection Reason (if rejecting)</p>
                    <Textarea
                      placeholder="Enter reason for rejection..."
                      value={rejectReason}
                      onChange={(e) => setRejectReason(e.target.value)}
                    />
                  </div>
                )}
              </div>
            )}

            <DialogFooter>
              {selectedDonation?.status === 'pending' && (
                <>
                  <Button
                    variant="outline"
                    onClick={() => handleReject(selectedDonation)}
                    className="text-red-600"
                    disabled={!rejectReason}
                  >
                    <X className="w-4 h-4 mr-2" />
                    Reject
                  </Button>
                  <Button
                    onClick={() => handleVerify(selectedDonation)}
                    className="bg-emerald-600 hover:bg-emerald-700"
                  >
                    <Check className="w-4 h-4 mr-2" />
                    Verify Donation
                  </Button>
                </>
              )}
              <Button variant="outline" onClick={() => setSelectedDonation(null)}>
                Close
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </main>
    </div>
  );
}