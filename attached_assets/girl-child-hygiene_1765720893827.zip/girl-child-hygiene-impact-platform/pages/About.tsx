import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { base44 } from '@/services/base44Client';
import { useQuery } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import { 
  Heart, Target, Eye, Shield, Users, Award, 
  Download, ArrowRight, CheckCircle2, Globe,
  Lightbulb, HandHeart
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import SectionHeading from '@/components/ui/SectionHeading';

export default function About() {
  const { data: teamMembers = [] } = useQuery({
    queryKey: ['team-board'],
    queryFn: () => base44.entities.TeamMember.filter({ is_active: true, category: 'board' }),
  });

  const values = [
    { icon: Heart, title: 'Compassion', description: 'We act with empathy and care for every girl and community we serve.' },
    { icon: Shield, title: 'Integrity', description: 'Transparency and accountability guide every decision we make.' },
    { icon: Users, title: 'Empowerment', description: 'We believe in building capacity, not dependency.' },
    { icon: Globe, title: 'Inclusivity', description: 'Every girl deserves dignity, regardless of her circumstances.' },
    { icon: Lightbulb, title: 'Innovation', description: 'We seek creative solutions to complex challenges.' },
    { icon: HandHeart, title: 'Sustainability', description: 'We build programs that create lasting change.' },
  ];

  const milestones = [
    { year: '2019', title: 'Founded', description: 'Started with a mission to support 100 girls' },
    { year: '2020', title: 'First Distribution', description: 'Reached 1,000 girls in 5 communities' },
    { year: '2021', title: 'Education Program', description: 'Launched back-to-school initiative' },
    { year: '2022', title: 'Training Center', description: 'Opened first pad production training facility' },
    { year: '2023', title: '10K Milestone', description: 'Supported over 10,000 girls' },
    { year: '2024', title: 'Global Expansion', description: 'Expanded to 5 African countries' },
  ];

  return (
    <div className="min-h-screen pt-20">
      {/* Hero Section */}
      <section className="relative py-24 overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="https://images.unsplash.com/photo-1529390079861-591f93f8a587?w=1920&q=80"
            alt="Community gathering"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-gray-900/95 to-gray-900/80" />
        </div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-3xl"
          >
            <span className="inline-block bg-rose-500/20 text-rose-300 text-sm font-semibold px-4 py-2 rounded-full mb-6">
              Our Story
            </span>
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6">
              Breaking Barriers, Building Futures
            </h1>
            <p className="text-xl text-gray-300 leading-relaxed">
              We're a dedicated team working to ensure that no girl misses school or 
              opportunities due to menstrual health challenges or lack of access to education.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Story Section */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
                Our Journey Began With a Simple Question
              </h2>
              <div className="space-y-4 text-gray-600 leading-relaxed">
                <p>
                  In 2019, our founders visited a rural school and discovered that 
                  nearly 40% of girls were absent. The reason? They couldn't afford 
                  sanitary products and lacked proper hygiene facilities.
                </p>
                <p>
                  This revelation sparked a mission: to ensure that menstruation 
                  never becomes a barrier to education. What started as distributing 
                  pads to one school has grown into a comprehensive movement 
                  addressing hygiene, education, and economic empowerment.
                </p>
                <p>
                  Today, we work across multiple countries, supporting tens of 
                  thousands of girls while training local women to produce 
                  sustainable menstrual products—creating a cycle of dignity 
                  and opportunity.
                </p>
              </div>
              <Link to={createPageUrl('Impact')}>
                <Button className="mt-8 bg-gradient-to-r from-rose-500 to-amber-500 text-white">
                  See Our Impact
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </Link>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="relative"
            >
              <div className="grid grid-cols-2 gap-4">
                <img
                  src="https://images.unsplash.com/photo-1594708767771-a7502209ff51?w=400&q=80"
                  alt="Girls receiving supplies"
                  className="rounded-2xl shadow-lg"
                />
                <img
                  src="https://images.unsplash.com/photo-1497633762265-9d179a990aa6?w=400&q=80"
                  alt="Education support"
                  className="rounded-2xl shadow-lg mt-8"
                />
                <img
                  src="https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?w=400&q=80"
                  alt="Community workshop"
                  className="rounded-2xl shadow-lg -mt-4"
                />
                <img
                  src="https://images.unsplash.com/photo-1509099836639-18ba1795216d?w=400&q=80"
                  alt="Happy students"
                  className="rounded-2xl shadow-lg mt-4"
                />
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="bg-white rounded-3xl p-8 shadow-lg border border-gray-100"
            >
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-rose-500 to-pink-600 flex items-center justify-center mb-6">
                <Target className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">Our Mission</h3>
              <p className="text-gray-600 leading-relaxed">
                To empower girls and women through menstrual hygiene support, 
                education access, and sustainable livelihood opportunities, 
                ensuring that every girl can pursue her dreams with dignity.
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1 }}
              className="bg-white rounded-3xl p-8 shadow-lg border border-gray-100"
            >
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center mb-6">
                <Eye className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">Our Vision</h3>
              <p className="text-gray-600 leading-relaxed">
                A world where menstruation is never a barrier to opportunity, 
                where every girl has access to quality education, and where 
                communities are equipped to sustain their own development.
              </p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Core Values */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <SectionHeading
            title="Our Core Values"
            subtitle="The principles that guide everything we do"
          />

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {values.map((value, index) => (
              <motion.div
                key={value.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="flex gap-4 p-6 rounded-2xl hover:bg-gray-50 transition-colors"
              >
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-rose-100 to-amber-100 flex items-center justify-center flex-shrink-0">
                  <value.icon className="w-6 h-6 text-rose-600" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-gray-900 mb-2">{value.title}</h3>
                  <p className="text-gray-600">{value.description}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Timeline */}
      <section className="py-24 bg-gradient-to-br from-gray-900 to-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <SectionHeading
            title="Our Journey"
            subtitle="Key milestones in our growth and impact"
            light
          />

          <div className="relative">
            {/* Timeline line */}
            <div className="absolute left-1/2 transform -translate-x-1/2 w-1 h-full bg-gradient-to-b from-rose-500 to-amber-500 hidden md:block" />

            <div className="space-y-12">
              {milestones.map((milestone, index) => (
                <motion.div
                  key={milestone.year}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  className={`flex items-center gap-8 ${
                    index % 2 === 0 ? 'md:flex-row' : 'md:flex-row-reverse'
                  }`}
                >
                  <div className={`flex-1 ${index % 2 === 0 ? 'md:text-right' : 'md:text-left'}`}>
                    <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 border border-white/10 inline-block">
                      <span className="text-rose-400 font-bold text-lg">{milestone.year}</span>
                      <h3 className="text-xl font-bold text-white mt-2">{milestone.title}</h3>
                      <p className="text-gray-300 mt-2">{milestone.description}</p>
                    </div>
                  </div>
                  <div className="w-4 h-4 rounded-full bg-gradient-to-r from-rose-500 to-amber-500 hidden md:block relative z-10" />
                  <div className="flex-1 hidden md:block" />
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Legal Documents */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-gradient-to-br from-gray-50 to-rose-50 rounded-3xl p-8 md:p-12">
            <div className="flex flex-col md:flex-row items-center justify-between gap-8">
              <div>
                <h3 className="text-2xl font-bold text-gray-900 mb-2">
                  Legal Registration & Compliance
                </h3>
                <p className="text-gray-600">
                  We're a registered non-profit organization operating with full transparency and accountability.
                </p>
              </div>
              <div className="flex flex-wrap gap-4">
                <Button variant="outline" className="border-2">
                  <Download className="w-4 h-4 mr-2" />
                  Registration Certificate
                </Button>
                <Button variant="outline" className="border-2">
                  <Download className="w-4 h-4 mr-2" />
                  Annual Reports
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-24 bg-gradient-to-r from-rose-600 to-amber-600">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
              Join Us in Making a Difference
            </h2>
            <p className="text-xl text-white/90 mb-8">
              Whether through donations, volunteering, or partnership, 
              there's a place for you in our mission.
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <Link to={createPageUrl('Donate')}>
                <Button size="lg" className="bg-white text-rose-600 hover:bg-gray-100">
                  <Heart className="w-5 h-5 mr-2" />
                  Donate Now
                </Button>
              </Link>
              <Link to={createPageUrl('Volunteer')}>
                <Button size="lg" variant="outline" className="border-2 border-white text-white hover:bg-white/10">
                  <Users className="w-5 h-5 mr-2" />
                  Volunteer
                </Button>
              </Link>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}