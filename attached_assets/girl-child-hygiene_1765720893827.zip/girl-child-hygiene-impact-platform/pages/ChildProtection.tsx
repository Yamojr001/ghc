import React from 'react';
import { ShieldCheck } from 'lucide-react';

export default function ChildProtection() {
  return (
    <div className="min-h-screen pt-20 bg-gray-50">
      <section className="py-16 bg-white">
        <div className="max-w-4xl mx-auto px-4">
          <div className="text-center mb-12">
            <ShieldCheck className="w-12 h-12 text-rose-500 mx-auto mb-4" />
            <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Child Protection Policy
            </h1>
            <p className="text-gray-600">Last updated: January 2024</p>
          </div>

          <div className="prose prose-lg max-w-none">
            <h2>1. Our Commitment</h2>
            <p>
              Girl Child Hygiene & Education Impact Platform is committed to the safety and wellbeing of all children we serve. We have zero tolerance for child abuse, exploitation, or neglect in any form.
            </p>

            <h2>2. Scope</h2>
            <p>
              This policy applies to all staff, volunteers, board members, partners, and anyone working on behalf of our organization who may come into contact with children through our programs.
            </p>

            <h2>3. Definitions</h2>
            <p>
              For the purposes of this policy, a "child" is any person under the age of 18, regardless of the age of majority in their country.
            </p>

            <h2>4. Key Principles</h2>
            <ul>
              <li>The best interests of the child are paramount in all decisions</li>
              <li>All children have equal rights to protection</li>
              <li>All concerns about children will be taken seriously</li>
              <li>We work in partnership with children, families, and communities</li>
              <li>Prevention is key to child protection</li>
            </ul>

            <h2>5. Standards of Conduct</h2>
            <p>All representatives of our organization must:</p>
            <ul>
              <li>Treat all children with respect and dignity</li>
              <li>Never be alone with a child in an unsupervised setting</li>
              <li>Never use inappropriate language or behavior around children</li>
              <li>Never engage in any form of physical punishment</li>
              <li>Report any concerns or incidents immediately</li>
              <li>Maintain appropriate boundaries at all times</li>
            </ul>

            <h2>6. Photography and Media</h2>
            <p>When photographing or filming children:</p>
            <ul>
              <li>Obtain informed consent from the child and their guardian</li>
              <li>Ensure images are dignified and respectful</li>
              <li>Never share identifying information without consent</li>
              <li>Store images securely and appropriately</li>
              <li>Use images only for approved purposes</li>
            </ul>

            <h2>7. Recruitment and Training</h2>
            <p>
              All staff and volunteers working with children undergo background checks and receive child protection training before starting their roles. Refresher training is provided annually.
            </p>

            <h2>8. Reporting Concerns</h2>
            <p>
              Anyone who suspects or witnesses abuse, exploitation, or neglect must report immediately to our designated Child Protection Officer. Reports can be made:
            </p>
            <ul>
              <li>In person to any manager</li>
              <li>Via email: childprotection@girlchildhygiene.org</li>
              <li>Via confidential hotline: +1 (555) 999-SAFE</li>
            </ul>

            <h2>9. Investigation Procedures</h2>
            <p>
              All reports are taken seriously and investigated promptly. Investigations are conducted confidentially by trained personnel, and appropriate action is taken based on findings.
            </p>

            <h2>10. Partner Requirements</h2>
            <p>
              All implementing partners must demonstrate they have child protection policies and procedures in place that meet our minimum standards.
            </p>

            <h2>11. Review</h2>
            <p>
              This policy is reviewed annually and updated as needed to reflect best practices and legal requirements.
            </p>

            <h2>12. Contact</h2>
            <p>
              Child Protection Officer: Dr. Amina Ibrahim<br />
              Email: childprotection@girlchildhygiene.org<br />
              Confidential Hotline: +1 (555) 999-SAFE
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}