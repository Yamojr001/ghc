import React from 'react';
import { base44 } from '@/services/base44Client';
import { useQuery } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import { Linkedin, Twitter, Mail } from 'lucide-react';
import SectionHeading from '@/components/ui/SectionHeading';

export default function Team() {
  const { data: teamMembers = [] } = useQuery({
    queryKey: ['team-members'],
    queryFn: () => base44.entities.TeamMember.filter({ is_active: true }),
  });

  const groupedTeam = teamMembers.length > 0 
    ? teamMembers.reduce((acc: any, member: any) => {
        const category = member.category || 'staff';
        if (!acc[category]) acc[category] = [];
        acc[category].push(member);
        return acc;
      }, {})
    : {};

  return (
    <div className="min-h-screen pt-20 bg-gray-50">
      {/* Hero */}
      <section className="relative py-24 overflow-hidden bg-white">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h1 className="text-3xl md:text-5xl font-bold text-gray-900 mb-4">
            Our Team
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Meet the passionate individuals dedicated to our mission of empowering girls through hygiene and education.
          </p>
        </div>
      </section>

      {/* Board of Trustees */}
      <section className="py-20 bg-white">
        <div className="max-w-6xl mx-auto px-4">
          <SectionHeading
            title="Board of Trustees"
            subtitle="Our governing body providing strategic direction and oversight"
          />

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {(groupedTeam.board || []).map((member: any, index: number) => (
              <TeamMemberCard key={member.name} member={member} index={index} />
            ))}
          </div>
        </div>
      </section>

      {/* Advisors */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-6xl mx-auto px-4">
          <SectionHeading
            title="Advisory Board"
            subtitle="Expert advisors guiding our programs and strategy"
          />

          <div className="grid md:grid-cols-3 gap-8">
            {(groupedTeam.advisors || groupedTeam.advisor || []).map((member: any, index: number) => (
              <TeamMemberCard key={member.name} member={member} index={index} />
            ))}
          </div>
        </div>
      </section>

      {/* Staff */}
      <section className="py-20 bg-white">
        <div className="max-w-6xl mx-auto px-4">
          <SectionHeading
            title="Leadership Team"
            subtitle="The dedicated professionals driving our daily operations"
          />

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {(groupedTeam.staff || []).map((member: any, index: number) => (
              <TeamMemberCard key={member.name} member={member} index={index} />
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}

function TeamMemberCard({ member, index }: any) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ delay: index * 0.1 }}
      className="group"
    >
      <div className="bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300">
        <div className="relative h-64 overflow-hidden">
          <img
            src={member.image_url}
            alt={member.name}
            className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-500"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity">
            <div className="absolute bottom-4 left-4 right-4 flex justify-center gap-3">
              {member.linkedin && (
                <a href={member.linkedin} className="w-10 h-10 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center text-white hover:bg-white hover:text-gray-900 transition-colors">
                  <Linkedin className="w-5 h-5" />
                </a>
              )}
              {member.twitter && (
                <a href={member.twitter} className="w-10 h-10 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center text-white hover:bg-white hover:text-gray-900 transition-colors">
                  <Twitter className="w-5 h-5" />
                </a>
              )}
              {member.email && (
                <a href={`mailto:${member.email}`} className="w-10 h-10 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center text-white hover:bg-white hover:text-gray-900 transition-colors">
                  <Mail className="w-5 h-5" />
                </a>
              )}
            </div>
          </div>
        </div>
        <div className="p-6 text-center">
          <h3 className="text-lg font-bold text-gray-900 mb-1">{member.name}</h3>
          <p className="text-rose-600 text-sm font-medium mb-3">{member.title}</p>
          <p className="text-gray-600 text-sm line-clamp-3">{member.bio}</p>
        </div>
      </div>
    </motion.div>
  );
}