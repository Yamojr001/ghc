import React from 'react';
import { base44 } from '@/services/base44Client';
import { useQuery } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import { 
  Shield, Download, TrendingUp, 
  TrendingDown, PieChart, FileText, CheckCircle2,
  Wallet
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, 
  ResponsiveContainer, PieChart as RechartsPie, Pie, Cell
} from 'recharts';
import SectionHeading from '@/components/ui/SectionHeading';

const incomeData = [
  { month: 'Jan', individual: 45000, corporate: 25000, grants: 15000 },
  { month: 'Feb', individual: 52000, corporate: 18000, grants: 20000 },
  { month: 'Mar', individual: 48000, corporate: 32000, grants: 25000 },
  { month: 'Apr', individual: 61000, corporate: 28000, grants: 18000 },
  { month: 'May', individual: 55000, corporate: 35000, grants: 22000 },
  { month: 'Jun', individual: 72000, corporate: 42000, grants: 30000 },
];

const expenseCategories = [
  { name: 'Program Delivery', value: 65, amount: 520000, color: '#f43f5e' },
  { name: 'Supplies & Materials', value: 15, amount: 120000, color: '#f59e0b' },
  { name: 'Staff & Training', value: 10, amount: 80000, color: '#10b981' },
  { name: 'Logistics', value: 5, amount: 40000, color: '#3b82f6' },
  { name: 'Admin & Overhead', value: 5, amount: 40000, color: '#8b5cf6' },
];

const financialSummary = {
  totalIncome: 850000,
  totalExpenses: 800000,
  netAssets: 250000,
  programExpenseRatio: 95,
  adminExpenseRatio: 5,
  fundraisingEfficiency: 92,
};

export default function Transparency() {
  const { data: expenses = [] } = useQuery({
    queryKey: ['expenses-approved'],
    queryFn: () => base44.entities.Expense.filter({ status: 'approved' }),
  });

  return (
    <div className="min-h-screen pt-20 bg-gray-50">
      {/* Hero */}
      <section className="relative py-24 overflow-hidden bg-gradient-to-br from-emerald-600 via-emerald-500 to-teal-500">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-10 left-10 w-96 h-96 bg-white rounded-full blur-3xl" />
          <div className="absolute bottom-10 right-10 w-96 h-96 bg-white rounded-full blur-3xl" />
        </div>
        <div className="relative max-w-4xl mx-auto px-4 text-center">
          <Shield className="w-16 h-16 text-white/80 mx-auto mb-6" />
          <h1 className="text-3xl md:text-5xl font-bold text-white mb-4">
            Transparency & Financials
          </h1>
          <p className="text-xl text-white/90 max-w-2xl mx-auto">
            We believe in complete transparency. See exactly how your donations are used.
          </p>
        </div>
      </section>

      {/* Key Metrics */}
      <section className="py-12 -mt-8 relative z-10">
        <div className="max-w-6xl mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-6">
            {[
              { 
                icon: TrendingUp, 
                label: 'Total Income (YTD)', 
                value: `$${financialSummary.totalIncome.toLocaleString()}`,
                color: 'text-emerald-600',
                bgColor: 'bg-emerald-50'
              },
              { 
                icon: TrendingDown, 
                label: 'Total Expenses (YTD)', 
                value: `$${financialSummary.totalExpenses.toLocaleString()}`,
                color: 'text-rose-600',
                bgColor: 'bg-rose-50'
              },
              { 
                icon: PieChart, 
                label: 'Program Expense Ratio', 
                value: `${financialSummary.programExpenseRatio}%`,
                color: 'text-blue-600',
                bgColor: 'bg-blue-50'
              },
              { 
                icon: Wallet, 
                label: 'Admin Overhead', 
                value: `${financialSummary.adminExpenseRatio}%`,
                color: 'text-purple-600',
                bgColor: 'bg-purple-50'
              },
            ].map((metric, index) => (
              <motion.div
                key={metric.label}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="bg-white rounded-2xl p-6 shadow-xl"
              >
                <div className={`w-12 h-12 rounded-xl ${metric.bgColor} flex items-center justify-center mb-4`}>
                  <metric.icon className={`w-6 h-6 ${metric.color}`} />
                </div>
                <div className="text-2xl font-bold text-gray-900">{metric.value}</div>
                <div className="text-sm text-gray-500">{metric.label}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Income Chart */}
      <section className="py-20 bg-white">
        <div className="max-w-6xl mx-auto px-4">
          <SectionHeading
            title="Income Sources"
            subtitle="Monthly breakdown of donation categories"
          />

          <div className="bg-gray-50 rounded-3xl p-8">
            <ResponsiveContainer width="100%" height={400}>
              <BarChart data={incomeData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                <XAxis dataKey="month" stroke="#6b7280" />
                <YAxis stroke="#6b7280" tickFormatter={(value) => `$${value / 1000}K`} />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'white', 
                    borderRadius: '12px', 
                    border: '1px solid #e5e7eb' 
                  }}
                  formatter={(value: any) => `$${value.toLocaleString()}`}
                />
                <Bar dataKey="individual" stackId="a" fill="#f43f5e" name="Individual Donors" radius={[0, 0, 0, 0]} />
                <Bar dataKey="corporate" stackId="a" fill="#f59e0b" name="Corporate Sponsors" radius={[0, 0, 0, 0]} />
                <Bar dataKey="grants" stackId="a" fill="#10b981" name="Grants" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
            <div className="flex justify-center gap-8 mt-6 flex-wrap">
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 rounded bg-rose-500" />
                <span className="text-sm text-gray-600">Individual Donors</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 rounded bg-amber-500" />
                <span className="text-sm text-gray-600">Corporate Sponsors</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 rounded bg-emerald-500" />
                <span className="text-sm text-gray-600">Grants</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Expense Breakdown */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-6xl mx-auto px-4">
          <SectionHeading
            title="Expense Breakdown"
            subtitle="How we allocate funds across our operations"
          />

          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="flex justify-center">
              <ResponsiveContainer width={350} height={350}>
                <RechartsPie>
                  <Pie
                    data={expenseCategories}
                    dataKey="value"
                    nameKey="name"
                    cx="50%"
                    cy="50%"
                    outerRadius={140}
                    innerRadius={80}
                    paddingAngle={3}
                    label={({ value }) => `${value}%`}
                    labelLine={false}
                  >
                    {expenseCategories.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value, name, props: any) => [`$${props.payload.amount.toLocaleString()}`, name]} />
                </RechartsPie>
              </ResponsiveContainer>
            </div>

            <div className="space-y-4">
              {expenseCategories.map((category) => (
                <motion.div
                  key={category.name}
                  initial={{ opacity: 0, x: 20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  className="bg-white rounded-xl p-4 shadow-sm flex items-center justify-between"
                >
                  <div className="flex items-center gap-4">
                    <div 
                      className="w-4 h-4 rounded-full"
                      style={{ backgroundColor: category.color }}
                    />
                    <div>
                      <div className="font-medium text-gray-900">{category.name}</div>
                      <div className="text-sm text-gray-500">{category.value}% of expenses</div>
                    </div>
                  </div>
                  <div className="text-lg font-bold text-gray-900">
                    ${category.amount.toLocaleString()}
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Financial Standards */}
      <section className="py-20 bg-white">
        <div className="max-w-6xl mx-auto px-4">
          <SectionHeading
            title="Our Commitment to Accountability"
            subtitle="We adhere to the highest standards of financial transparency"
          />

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                title: 'Annual Audits',
                description: 'Independent auditors review our finances annually to ensure accuracy and compliance.',
                icon: FileText
              },
              {
                title: '95%+ to Programs',
                description: 'At least 95 cents of every dollar goes directly to our programs and beneficiaries.',
                icon: TrendingUp
              },
              {
                title: 'Real-Time Tracking',
                description: 'Our field verification system provides GPS-verified proof of every distribution.',
                icon: CheckCircle2
              },
            ].map((item, index) => (
              <motion.div
                key={item.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="text-center"
              >
                <div className="w-16 h-16 rounded-2xl bg-emerald-100 flex items-center justify-center mx-auto mb-4">
                  <item.icon className="w-8 h-8 text-emerald-600" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">{item.title}</h3>
                <p className="text-gray-600">{item.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Download Reports */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-6xl mx-auto px-4">
          <SectionHeading
            title="Financial Reports"
            subtitle="Download our audited financial statements and reports"
          />

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { title: 'Annual Report 2024', type: 'Annual Report', size: '2.4 MB' },
              { title: 'Q3 2024 Financials', type: 'Quarterly Report', size: '1.1 MB' },
              { title: 'Audit Report 2023', type: 'Audit Report', size: '3.2 MB' },
              { title: 'Budget 2024', type: 'Budget Document', size: '890 KB' },
            ].map((report, index) => (
              <motion.div
                key={report.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="bg-white rounded-2xl p-6 shadow-sm hover:shadow-lg transition-shadow"
              >
                <div className="w-12 h-12 rounded-xl bg-emerald-100 flex items-center justify-center mb-4">
                  <FileText className="w-6 h-6 text-emerald-600" />
                </div>
                <h3 className="font-bold text-gray-900 mb-1">{report.title}</h3>
                <p className="text-sm text-gray-500 mb-4">{report.type} • {report.size}</p>
                <Button variant="outline" className="w-full" size="sm">
                  <Download className="w-4 h-4 mr-2" />
                  Download
                </Button>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}