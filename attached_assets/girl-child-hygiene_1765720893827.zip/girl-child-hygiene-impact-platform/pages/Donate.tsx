import React, { useState } from 'react';
import { base44 } from '@/services/base44Client';
import { useMutation } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Heart, Loader2 } from 'lucide-react';

export default function Donate() {
  const [amount, setAmount] = useState('10');
  const [email, setEmail] = useState('');
  
  const createDonationMutation = useMutation({
    mutationFn: async (donationData: any) => {
      return await base44.entities.Donation.create(donationData);
    },
    onSuccess: (data) => {
      alert(`Donation of $${data.amount} recorded! ID: ${data.id}`);
      setAmount('10');
      setEmail('');
    },
    onError: (error) => {
      alert("Error processing donation. Please ensure backend is running.");
      console.error(error);
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createDonationMutation.mutate({
      donor_email: email,
      amount: parseFloat(amount),
      currency: 'USD',
      amount_usd: parseFloat(amount),
      category: 'general',
      payment_method: 'bank_transfer',
      status: 'pending',
      donor_name: 'Website Donor'
    });
  };

  return (
    <div className="min-h-screen pt-24 px-4 bg-gray-50 flex items-center justify-center">
      <div className="max-w-md w-full bg-white p-8 rounded-2xl shadow-xl">
        <div className="text-center mb-8">
          <Heart className="w-12 h-12 text-rose-500 mx-auto mb-4" />
          <h1 className="text-2xl font-bold text-gray-900">Make a Donation</h1>
          {/* <p className="text-gray-600">Connects to Laravel API</p> */}
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
            <input 
              type="email" 
              className="w-full p-2 border rounded-md"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Amount (USD)</label>
            <input 
              type="number" 
              className="w-full p-2 border rounded-md"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              required
            />
          </div>
          
          <Button 
            className="w-full bg-gradient-to-r from-rose-500 to-amber-500"
            disabled={createDonationMutation.isPending}
          >
            {createDonationMutation.isPending ? (
              <Loader2 className="w-4 h-4 animate-spin mr-2" />
            ) : (
              <Heart className="w-4 h-4 mr-2" />
            )}
            Donate Now
          </Button>
        </form>
      </div>
    </div>
  );
}
