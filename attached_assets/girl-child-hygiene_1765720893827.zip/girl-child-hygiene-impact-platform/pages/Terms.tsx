import React from 'react';
import { FileText } from 'lucide-react';

export default function Terms() {
  return (
    <div className="min-h-screen pt-20 bg-gray-50">
      <section className="py-16 bg-white">
        <div className="max-w-4xl mx-auto px-4">
          <div className="text-center mb-12">
            <FileText className="w-12 h-12 text-rose-500 mx-auto mb-4" />
            <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Terms of Service
            </h1>
            <p className="text-gray-600">Last updated: January 2024</p>
          </div>

          <div className="prose prose-lg max-w-none">
            <h2>1. Acceptance of Terms</h2>
            <p>
              By accessing and using the Girl Child Hygiene & Education Impact Platform website, you accept and agree to be bound by these Terms of Service. If you do not agree, please do not use our website.
            </p>

            <h2>2. About Our Organization</h2>
            <p>
              Girl Child Hygiene & Education Impact Platform is a registered nonprofit organization dedicated to providing menstrual hygiene support, education access, and livelihood training to girls and women.
            </p>

            <h2>3. Donations</h2>
            <h3>General Terms</h3>
            <ul>
              <li>All donations are voluntary and non-refundable unless made in error.</li>
              <li>Donations are used in accordance with our stated programs and mission.</li>
              <li>Tax receipts are provided for eligible donations.</li>
              <li>Recurring donations can be cancelled at any time.</li>
            </ul>

            <h3>Payment Processing</h3>
            <p>
              We use secure third-party payment processors. By making a donation, you agree to their terms of service as well.
            </p>

            <h2>4. User Conduct</h2>
            <p>When using our website, you agree not to:</p>
            <ul>
              <li>Provide false or misleading information</li>
              <li>Violate any applicable laws or regulations</li>
              <li>Attempt to gain unauthorized access to our systems</li>
              <li>Transmit harmful code or malware</li>
              <li>Harass or harm others</li>
            </ul>

            <h2>5. Intellectual Property</h2>
            <p>
              All content on this website, including text, images, logos, and graphics, is owned by or licensed to us. You may not reproduce, distribute, or create derivative works without our written permission.
            </p>

            <h2>6. Third-Party Links</h2>
            <p>
              Our website may contain links to third-party websites. We are not responsible for the content or practices of these external sites.
            </p>

            <h2>7. Disclaimer of Warranties</h2>
            <p>
              Our website is provided "as is" without warranties of any kind. We do not guarantee that the website will be error-free or uninterrupted.
            </p>

            <h2>8. Limitation of Liability</h2>
            <p>
              To the fullest extent permitted by law, we shall not be liable for any indirect, incidental, or consequential damages arising from your use of our website.
            </p>

            <h2>9. Indemnification</h2>
            <p>
              You agree to indemnify and hold harmless our organization, its officers, directors, employees, and volunteers from any claims arising from your use of the website.
            </p>

            <h2>10. Changes to Terms</h2>
            <p>
              We reserve the right to modify these terms at any time. Continued use of the website after changes constitutes acceptance of the new terms.
            </p>

            <h2>11. Governing Law</h2>
            <p>
              These terms shall be governed by and construed in accordance with the laws of the State of New York, USA.
            </p>

            <h2>12. Contact Information</h2>
            <p>
              For questions about these Terms of Service, contact us at:<br />
              Email: legal@girlchildhygiene.org<br />
              Address: 123 Impact Street, New York, NY 10001, USA
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}