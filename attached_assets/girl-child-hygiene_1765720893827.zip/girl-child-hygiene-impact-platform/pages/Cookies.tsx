import React from 'react';
import { Cookie } from 'lucide-react';

export default function Cookies() {
  return (
    <div className="min-h-screen pt-20 bg-gray-50">
      <section className="py-16 bg-white">
        <div className="max-w-4xl mx-auto px-4">
          <div className="text-center mb-12">
            <Cookie className="w-12 h-12 text-rose-500 mx-auto mb-4" />
            <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Cookie Policy
            </h1>
            <p className="text-gray-600">Last updated: January 2024</p>
          </div>

          <div className="prose prose-lg max-w-none">
            <h2>1. What Are Cookies?</h2>
            <p>
              Cookies are small text files that are placed on your device when you visit a website. They are widely used to make websites work more efficiently and to provide information to website owners.
            </p>

            <h2>2. How We Use Cookies</h2>
            <p>We use cookies for the following purposes:</p>
            
            <h3>Essential Cookies</h3>
            <p>
              These cookies are necessary for the website to function properly. They enable core functionality such as security, network management, and accessibility.
            </p>

            <h3>Analytics Cookies</h3>
            <p>
              We use analytics cookies to understand how visitors interact with our website. This helps us improve our website and user experience. These cookies collect anonymous information.
            </p>

            <h3>Functionality Cookies</h3>
            <p>
              These cookies allow the website to remember choices you make (such as your language preference) and provide enhanced features.
            </p>

            <h3>Marketing Cookies</h3>
            <p>
              We may use marketing cookies to track visitors across websites to display relevant advertisements. We will only use these with your consent.
            </p>

            <h2>3. Third-Party Cookies</h2>
            <p>
              Some cookies are placed by third parties, such as payment processors, analytics providers, and social media platforms. These third parties have their own privacy policies.
            </p>

            <h2>4. Managing Cookies</h2>
            <p>
              You can control and manage cookies in various ways:
            </p>
            <ul>
              <li><strong>Browser Settings:</strong> Most browsers allow you to manage cookies through their settings</li>
              <li><strong>Cookie Banner:</strong> Use our cookie consent banner to manage preferences</li>
              <li><strong>Third-Party Tools:</strong> Use opt-out tools provided by analytics providers</li>
            </ul>

            <h2>5. Cookies We Use</h2>
            <table className="w-full border-collapse border border-gray-300 mt-4">
              <thead>
                <tr className="bg-gray-100">
                  <th className="border border-gray-300 p-2 text-left">Cookie Name</th>
                  <th className="border border-gray-300 p-2 text-left">Purpose</th>
                  <th className="border border-gray-300 p-2 text-left">Duration</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="border border-gray-300 p-2">session_id</td>
                  <td className="border border-gray-300 p-2">Maintains user session</td>
                  <td className="border border-gray-300 p-2">Session</td>
                </tr>
                <tr>
                  <td className="border border-gray-300 p-2">consent</td>
                  <td className="border border-gray-300 p-2">Stores cookie consent</td>
                  <td className="border border-gray-300 p-2">1 year</td>
                </tr>
                <tr>
                  <td className="border border-gray-300 p-2">_ga</td>
                  <td className="border border-gray-300 p-2">Google Analytics</td>
                  <td className="border border-gray-300 p-2">2 years</td>
                </tr>
              </tbody>
            </table>

            <h2>6. Changes to This Policy</h2>
            <p>
              We may update this Cookie Policy from time to time. We will notify you of any significant changes by posting a notice on our website.
            </p>

            <h2>7. Contact Us</h2>
            <p>
              If you have questions about our use of cookies, please contact us at:<br />
              Email: privacy@girlchildhygiene.org<br />
              Address: 123 Impact Street, New York, NY 10001, USA
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}