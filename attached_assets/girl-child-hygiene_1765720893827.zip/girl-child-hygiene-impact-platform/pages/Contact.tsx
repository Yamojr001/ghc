import React, { useState } from 'react';
import { base44 } from '@/services/base44Client';
import { useMutation } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import { 
  Mail, Phone, MapPin, Clock, 
  Send, Check, Loader2, MessageSquare,
  Facebook, Twitter, Instagram, Linkedin
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

const contactInfo = [
  {
    icon: Mail,
    title: 'Email Us',
    content: 'contact@girlchildhygiene.org',
    subtext: 'We respond within 24 hours'
  },
  {
    icon: Phone,
    title: 'Call Us',
    content: '+1 (555) 123-4567',
    subtext: 'Mon-Fri, 9am-6pm EST'
  },
  {
    icon: MapPin,
    title: 'Visit Us',
    content: 'Global Headquarters',
    subtext: 'New York, NY 10001, USA'
  },
  {
    icon: Clock,
    title: 'Office Hours',
    content: 'Mon - Fri: 9AM - 6PM',
    subtext: 'Weekend: By appointment'
  },
];

const inquiryTypes = [
  { value: 'general', label: 'General Inquiry' },
  { value: 'donation', label: 'Donation Question' },
  { value: 'partnership', label: 'Partnership Opportunity' },
  { value: 'volunteer', label: 'Volunteer Information' },
  { value: 'media', label: 'Media/Press Inquiry' },
  { value: 'other', label: 'Other' },
];

export default function Contact() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    subject: '',
    inquiry_type: '',
    message: ''
  });
  const [isSubmitted, setIsSubmitted] = useState(false);

  const submitMutation = useMutation({
    mutationFn: async (data: any) => {
      return await base44.entities.ContactMessage.create(data);
    },
    onSuccess: () => {
      setIsSubmitted(true);
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    submitMutation.mutate(formData);
  };

  if (isSubmitted) {
    return (
      <div className="min-h-screen pt-20 bg-gradient-to-b from-gray-50 to-white flex items-center justify-center">
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="max-w-md mx-auto text-center px-4"
        >
          <div className="w-24 h-24 rounded-full bg-gradient-to-r from-emerald-400 to-emerald-600 flex items-center justify-center mx-auto mb-6">
            <Check className="w-12 h-12 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-gray-900 mb-4">
            Message Sent!
          </h1>
          <p className="text-gray-600 mb-8">
            Thank you for reaching out. Our team will review your message and respond within 24-48 hours.
          </p>
          <Button onClick={() => window.location.href = '/'}>
            Return Home
          </Button>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-20 bg-gray-50">
      {/* Hero */}
      <section className="relative py-24 overflow-hidden bg-gradient-to-br from-rose-600 via-rose-500 to-amber-500">
        <div className="relative max-w-4xl mx-auto px-4 text-center">
          <MessageSquare className="w-16 h-16 text-white/80 mx-auto mb-6" />
          <h1 className="text-3xl md:text-5xl font-bold text-white mb-4">
            Get in Touch
          </h1>
          <p className="text-xl text-white/90 max-w-2xl mx-auto">
            Have questions? We'd love to hear from you. Send us a message and we'll respond as soon as possible.
          </p>
        </div>
      </section>

      {/* Contact Info Cards */}
      <section className="py-12 -mt-8 relative z-10">
        <div className="max-w-6xl mx-auto px-4">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {contactInfo.map((info, index) => (
              <motion.div
                key={info.title}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="bg-white rounded-2xl p-6 shadow-lg text-center"
              >
                <div className="w-12 h-12 rounded-xl bg-rose-100 flex items-center justify-center mx-auto mb-4">
                  <info.icon className="w-6 h-6 text-rose-600" />
                </div>
                <h3 className="font-bold text-gray-900 mb-1">{info.title}</h3>
                <p className="text-gray-900">{info.content}</p>
                <p className="text-sm text-gray-500 mt-1">{info.subtext}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Form */}
      <section className="py-20">
        <div className="max-w-6xl mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12">
            {/* Form */}
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
            >
              <h2 className="text-2xl font-bold text-gray-900 mb-6">
                Send Us a Message
              </h2>
              <form onSubmit={handleSubmit} className="bg-white rounded-3xl shadow-lg p-8">
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <Label className="mb-2 block">Full Name *</Label>
                    <Input
                      required
                      placeholder="Your name"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    />
                  </div>
                  <div>
                    <Label className="mb-2 block">Email *</Label>
                    <Input
                      type="email"
                      required
                      placeholder="your@email.com"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    />
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-6 mt-6">
                  <div>
                    <Label className="mb-2 block">Phone</Label>
                    <Input
                      placeholder="+1 234 567 8900"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    />
                  </div>
                  <div>
                    <Label className="mb-2 block">Inquiry Type *</Label>
                    <Select
                      value={formData.inquiry_type}
                      onValueChange={(value: string) => setFormData({ ...formData, inquiry_type: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select type" />
                      </SelectTrigger>
                      <SelectContent>
                        {inquiryTypes.map((type) => (
                          <SelectItem key={type.value} value={type.value}>
                            {type.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="mt-6">
                  <Label className="mb-2 block">Subject *</Label>
                  <Input
                    required
                    placeholder="What is this regarding?"
                    value={formData.subject}
                    onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                  />
                </div>

                <div className="mt-6">
                  <Label className="mb-2 block">Message *</Label>
                  <Textarea
                    required
                    placeholder="Your message..."
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    rows={5}
                  />
                </div>

                <Button
                  type="submit"
                  className="w-full mt-8 bg-gradient-to-r from-rose-500 to-amber-500 py-6"
                  disabled={submitMutation.isPending}
                >
                  {submitMutation.isPending ? (
                    <>
                      <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                      Sending...
                    </>
                  ) : (
                    <>
                      Send Message
                      <Send className="w-5 h-5 ml-2" />
                    </>
                  )}
                </Button>
              </form>
            </motion.div>

            {/* Map & Social */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
            >
              <h2 className="text-2xl font-bold text-gray-900 mb-6">
                Our Offices
              </h2>
              
              {/* Map Placeholder */}
              <div className="bg-gray-200 rounded-3xl h-64 mb-8 flex items-center justify-center">
                <div className="text-center text-gray-500">
                  <MapPin className="w-12 h-12 mx-auto mb-2" />
                  <p>Interactive map</p>
                </div>
              </div>

              {/* Regional Offices */}
              <div className="space-y-4 mb-8">
                {[
                  { city: 'New York', address: '123 Impact Street, NY 10001', phone: '+1 (555) 123-4567' },
                  { city: 'Lagos', address: '45 Victoria Island, Lagos', phone: '+234 (1) 234-5678' },
                  { city: 'Nairobi', address: '78 Westlands, Nairobi', phone: '+254 (20) 123-4567' },
                ].map((office) => (
                  <div key={office.city} className="bg-white rounded-xl p-4 shadow-sm">
                    <h4 className="font-bold text-gray-900">{office.city} Office</h4>
                    <p className="text-sm text-gray-600">{office.address}</p>
                    <p className="text-sm text-rose-600">{office.phone}</p>
                  </div>
                ))}
              </div>

              {/* Social Media */}
              <div>
                <h3 className="font-bold text-gray-900 mb-4">Connect With Us</h3>
                <div className="flex gap-4">
                  {[
                    { icon: Facebook, href: '#', label: 'Facebook' },
                    { icon: Twitter, href: '#', label: 'Twitter' },
                    { icon: Instagram, href: '#', label: 'Instagram' },
                    { icon: Linkedin, href: '#', label: 'LinkedIn' },
                  ].map((social) => (
                    <a
                      key={social.label}
                      href={social.href}
                      className="w-12 h-12 rounded-full bg-gray-100 hover:bg-rose-100 flex items-center justify-center text-gray-600 hover:text-rose-600 transition-colors"
                    >
                      <social.icon className="w-5 h-5" />
                    </a>
                  ))}
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>
    </div>
  );
}