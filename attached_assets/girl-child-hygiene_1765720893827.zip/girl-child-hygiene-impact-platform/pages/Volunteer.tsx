import React, { useState } from 'react';
import { base44 } from '@/services/base44Client';
import { useMutation } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import { 
  Users, Heart, Globe, Clock, 
  Check, Loader2, MapPin
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import SectionHeading from '@/components/ui/SectionHeading';

const volunteerRoles = [
  {
    title: 'Field Volunteer',
    description: 'Help with distribution events and community outreach',
    icon: MapPin,
    commitment: '4-8 hours/month'
  },
  {
    title: 'Workshop Facilitator',
    description: 'Lead hygiene education workshops in schools',
    icon: Users,
    commitment: '2-4 sessions/month'
  },
  {
    title: 'Digital Ambassador',
    description: 'Help spread awareness through social media',
    icon: Globe,
    commitment: '2-3 hours/week'
  },
  {
    title: 'Fundraiser',
    description: 'Organize fundraising events and campaigns',
    icon: Heart,
    commitment: 'Flexible'
  },
];

const skillOptions = [
  'Teaching/Education',
  'Healthcare',
  'Social Work',
  'Marketing/Communications',
  'Event Planning',
  'Photography/Videography',
  'Data Analysis',
  'Graphic Design',
  'Web Development',
  'Translation',
  'Project Management',
  'Other'
];

const interestAreas = [
  'Menstrual Hygiene Distribution',
  'Education Support',
  'Pad Production Training',
  'Community Outreach',
  'Fundraising',
  'Social Media/Awareness',
  'Administration',
  'Field Work'
];

export default function Volunteer() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    country: '',
    city: '',
    skills: [] as string[],
    availability: '',
    interest_areas: [] as string[],
    experience: '',
    motivation: ''
  });
  const [isSubmitted, setIsSubmitted] = useState(false);

  const submitMutation = useMutation({
    mutationFn: async (data: any) => {
      return await base44.entities.Volunteer.create(data);
    },
    onSuccess: () => {
      setIsSubmitted(true);
    }
  });

  const handleSkillToggle = (skill: string) => {
    setFormData(prev => ({
      ...prev,
      skills: prev.skills.includes(skill)
        ? prev.skills.filter(s => s !== skill)
        : [...prev.skills, skill]
    }));
  };

  const handleInterestToggle = (interest: string) => {
    setFormData(prev => ({
      ...prev,
      interest_areas: prev.interest_areas.includes(interest)
        ? prev.interest_areas.filter(i => i !== interest)
        : [...prev.interest_areas, interest]
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    submitMutation.mutate(formData);
  };

  if (isSubmitted) {
    return (
      <div className="min-h-screen pt-20 bg-gradient-to-b from-gray-50 to-white flex items-center justify-center">
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="max-w-md mx-auto text-center px-4"
        >
          <div className="w-24 h-24 rounded-full bg-gradient-to-r from-emerald-400 to-emerald-600 flex items-center justify-center mx-auto mb-6">
            <Check className="w-12 h-12 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-gray-900 mb-4">
            Application Received!
          </h1>
          <p className="text-gray-600 mb-8">
            Thank you for your interest in volunteering with us. Our team will review your application and contact you within 5-7 business days.
          </p>
          <Button onClick={() => window.location.href = '/'}>
            Return Home
          </Button>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-20">
      {/* Hero */}
      <section className="relative py-24 overflow-hidden bg-gradient-to-br from-purple-600 via-purple-500 to-rose-500">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-10 left-10 w-96 h-96 bg-white rounded-full blur-3xl" />
          <div className="absolute bottom-10 right-10 w-96 h-96 bg-white rounded-full blur-3xl" />
        </div>
        <div className="relative max-w-4xl mx-auto px-4 text-center">
          <Users className="w-16 h-16 text-white/80 mx-auto mb-6" />
          <h1 className="text-3xl md:text-5xl font-bold text-white mb-4">
            Join Our Volunteer Family
          </h1>
          <p className="text-xl text-white/90 max-w-2xl mx-auto">
            Your time and skills can transform lives. Become part of our mission to empower girls and communities.
          </p>
        </div>
      </section>

      {/* Volunteer Roles */}
      <section className="py-20 bg-white">
        <div className="max-w-6xl mx-auto px-4">
          <SectionHeading
            title="Volunteer Opportunities"
            subtitle="Find a role that matches your skills and availability"
          />

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {volunteerRoles.map((role, index) => (
              <motion.div
                key={role.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="bg-gray-50 rounded-2xl p-6 hover:shadow-lg transition-shadow"
              >
                <div className="w-12 h-12 rounded-xl bg-purple-100 flex items-center justify-center mb-4">
                  <role.icon className="w-6 h-6 text-purple-600" />
                </div>
                <h3 className="font-bold text-gray-900 mb-2">{role.title}</h3>
                <p className="text-gray-600 text-sm mb-4">{role.description}</p>
                <div className="flex items-center gap-2 text-sm text-gray-500">
                  <Clock className="w-4 h-4" />
                  {role.commitment}
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Application Form */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-3xl mx-auto px-4">
          <SectionHeading
            title="Apply to Volunteer"
            subtitle="Fill out the form below and we'll be in touch"
          />

          <motion.form
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            onSubmit={handleSubmit}
            className="bg-white rounded-3xl shadow-lg p-8"
          >
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <Label className="mb-2 block">Full Name *</Label>
                <Input
                  required
                  placeholder="Your full name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                />
              </div>
              <div>
                <Label className="mb-2 block">Email *</Label>
                <Input
                  type="email"
                  required
                  placeholder="your@email.com"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                />
              </div>
              <div>
                <Label className="mb-2 block">Phone</Label>
                <Input
                  placeholder="+1 234 567 8900"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                />
              </div>
              <div>
                <Label className="mb-2 block">Country *</Label>
                <Input
                  required
                  placeholder="Your country"
                  value={formData.country}
                  onChange={(e) => setFormData({ ...formData, country: e.target.value })}
                />
              </div>
              <div>
                <Label className="mb-2 block">City</Label>
                <Input
                  placeholder="Your city"
                  value={formData.city}
                  onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                />
              </div>
              <div>
                <Label className="mb-2 block">Availability *</Label>
                <Select
                  value={formData.availability}
                  onValueChange={(value: string) => setFormData({ ...formData, availability: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select availability" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="full_time">Full Time</SelectItem>
                    <SelectItem value="part_time">Part Time</SelectItem>
                    <SelectItem value="weekends">Weekends Only</SelectItem>
                    <SelectItem value="flexible">Flexible</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="mt-6">
              <Label className="mb-3 block">Skills (Select all that apply)</Label>
              <div className="flex flex-wrap gap-2">
                {skillOptions.map((skill) => (
                  <button
                    key={skill}
                    type="button"
                    onClick={() => handleSkillToggle(skill)}
                    className={`px-3 py-1.5 rounded-full text-sm font-medium transition-all ${
                      formData.skills.includes(skill)
                        ? 'bg-purple-500 text-white'
                        : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                    }`}
                  >
                    {skill}
                  </button>
                ))}
              </div>
            </div>

            <div className="mt-6">
              <Label className="mb-3 block">Areas of Interest *</Label>
              <div className="grid grid-cols-2 gap-3">
                {interestAreas.map((interest) => (
                  <div
                    key={interest}
                    className="flex items-center gap-2"
                  >
                    <Checkbox
                      checked={formData.interest_areas.includes(interest)}
                      onCheckedChange={() => handleInterestToggle(interest)}
                    />
                    <Label className="text-sm cursor-pointer">{interest}</Label>
                  </div>
                ))}
              </div>
            </div>

            <div className="mt-6">
              <Label className="mb-2 block">Relevant Experience</Label>
              <Textarea
                placeholder="Tell us about any relevant volunteer or work experience..."
                value={formData.experience}
                onChange={(e) => setFormData({ ...formData, experience: e.target.value })}
                rows={3}
              />
            </div>

            <div className="mt-6">
              <Label className="mb-2 block">Why do you want to volunteer with us? *</Label>
              <Textarea
                required
                placeholder="Share your motivation and what you hope to contribute..."
                value={formData.motivation}
                onChange={(e) => setFormData({ ...formData, motivation: e.target.value })}
                rows={4}
              />
            </div>

            <Button
              type="submit"
              className="w-full mt-8 bg-gradient-to-r from-purple-500 to-rose-500 py-6 text-lg"
              disabled={submitMutation.isPending}
            >
              {submitMutation.isPending ? (
                <>
                  <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                  Submitting...
                </>
              ) : (
                <>
                  Submit Application
                  <Heart className="w-5 h-5 ml-2" />
                </>
              )}
            </Button>
          </motion.form>
        </div>
      </section>
    </div>
  );
}