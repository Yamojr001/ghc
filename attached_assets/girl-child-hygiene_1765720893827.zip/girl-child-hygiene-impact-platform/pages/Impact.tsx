import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { base44 } from '@/services/base44Client';
import { useQuery } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import { 
  Package, Users, School, MapPin, 
  Heart, Download, BarChart3
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, 
  ResponsiveContainer, PieChart as RechartsPie, 
  Pie, Cell, AreaChart, Area
} from 'recharts';
import SectionHeading from '@/components/ui/SectionHeading';
import ImpactCounter from '@/components/ui/ImpactCounter';

const yearlyData = [
  { year: '2020', pads: 15000, girls: 5000, schools: 50 },
  { year: '2021', pads: 35000, girls: 12000, schools: 120 },
  { year: '2022', pads: 65000, girls: 25000, schools: 200 },
  { year: '2023', pads: 95000, girls: 38000, schools: 280 },
  { year: '2024', pads: 125000, girls: 45000, schools: 350 },
];

const projectedData = [
  { year: '2025', target: 200000, projected: 180000 },
  { year: '2026', target: 350000, projected: 320000 },
  { year: '2027', target: 500000, projected: 480000 },
  { year: '2028', target: 750000, projected: 700000 },
  { year: '2029', target: 1000000, projected: 950000 },
  { year: '2030', target: 1500000, projected: 1400000 },
];

const impactBreakdown = [
  { name: 'Menstrual Hygiene', value: 55, color: '#f43f5e' },
  { name: 'Education Support', value: 30, color: '#f59e0b' },
  { name: 'Training Programs', value: 15, color: '#10b981' },
];

const healthStats = [
  { metric: 'Reduction in school absenteeism', before: '40%', after: '8%', improvement: '80%' },
  { metric: 'Girls completing secondary school', before: '45%', after: '78%', improvement: '73%' },
  { metric: 'Menstrual health awareness', before: '25%', after: '92%', improvement: '268%' },
  { metric: 'Access to sanitary products', before: '30%', after: '95%', improvement: '217%' },
];

export default function Impact() {
  const { data: distributions = [] } = useQuery({
    queryKey: ['distributions-approved'],
    queryFn: () => base44.entities.Distribution.filter({ status: 'approved' }),
  });

  const totalPads = distributions.reduce((acc: number, d: any) => acc + (d.items_distributed || 0), 0) || 125000;
  const totalGirls = distributions.reduce((acc: number, d: any) => acc + (d.beneficiary_count || 0), 0) || 45000;
  const totalSchools = new Set(distributions.map((d: any) => d.location_name)).size || 350;
  const totalCommunities = new Set(distributions.map((d: any) => d.region)).size || 85;

  return (
    <div className="min-h-screen pt-20">
      {/* Hero */}
      <section className="relative py-24 overflow-hidden bg-gradient-to-br from-rose-600 via-rose-500 to-amber-500">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-10 left-10 w-96 h-96 bg-white rounded-full blur-3xl" />
          <div className="absolute bottom-10 right-10 w-96 h-96 bg-white rounded-full blur-3xl" />
        </div>
        <div className="relative max-w-4xl mx-auto px-4 text-center">
          <BarChart3 className="w-16 h-16 text-white/80 mx-auto mb-6" />
          <h1 className="text-3xl md:text-5xl font-bold text-white mb-4">
            Our Impact
          </h1>
          <p className="text-xl text-white/90 max-w-2xl mx-auto">
            Transparent reporting on how your donations are transforming lives and communities.
          </p>
        </div>
      </section>

      {/* Live Impact Stats */}
      <section className="py-16 -mt-8 relative z-10">
        <div className="max-w-6xl mx-auto px-4">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { value: totalPads, label: 'Pads Distributed', icon: Package },
              { value: totalGirls, label: 'Girls Supported', icon: Users },
              { value: totalSchools, label: 'Schools Reached', icon: School },
              { value: totalCommunities, label: 'Communities', icon: MapPin },
            ].map((stat, index) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="bg-white rounded-2xl p-6 shadow-xl"
              >
                <ImpactCounter
                  value={stat.value}
                  label={stat.label}
                  icon={stat.icon}
                />
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Growth Chart */}
      <section className="py-20 bg-white">
        <div className="max-w-6xl mx-auto px-4">
          <SectionHeading
            title="Year-Over-Year Growth"
            subtitle="Our journey of impact from 2020 to 2024"
          />

          <div className="bg-gray-50 rounded-3xl p-8">
            <ResponsiveContainer width="100%" height={400}>
              <AreaChart data={yearlyData}>
                <defs>
                  <linearGradient id="colorPads" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#f43f5e" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#f43f5e" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorGirls" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#f59e0b" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                <XAxis dataKey="year" stroke="#6b7280" />
                <YAxis stroke="#6b7280" />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'white', 
                    borderRadius: '12px', 
                    border: '1px solid #e5e7eb',
                    boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)'
                  }} 
                />
                <Area type="monotone" dataKey="pads" stroke="#f43f5e" strokeWidth={3} fillOpacity={1} fill="url(#colorPads)" name="Pads Distributed" />
                <Area type="monotone" dataKey="girls" stroke="#f59e0b" strokeWidth={3} fillOpacity={1} fill="url(#colorGirls)" name="Girls Supported" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      </section>

      {/* Projected Impact 2026-2030 */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-6xl mx-auto px-4">
          <SectionHeading
            title="Our Vision: 2025-2030"
            subtitle="Projected growth and ambitious targets for the next five years"
          />

          <div className="bg-white rounded-3xl p-8 shadow-lg">
            <ResponsiveContainer width="100%" height={400}>
              <BarChart data={projectedData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                <XAxis dataKey="year" stroke="#6b7280" />
                <YAxis stroke="#6b7280" tickFormatter={(value) => `${(value / 1000)}K`} />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'white', 
                    borderRadius: '12px', 
                    border: '1px solid #e5e7eb' 
                  }}
                  formatter={(value: any) => value.toLocaleString()}
                />
                <Bar dataKey="target" fill="#e5e7eb" name="Target" radius={[4, 4, 0, 0]} />
                <Bar dataKey="projected" fill="#f43f5e" name="Projected" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
            <div className="flex justify-center gap-8 mt-6">
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 rounded bg-gray-200" />
                <span className="text-sm text-gray-600">Target</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 rounded bg-rose-500" />
                <span className="text-sm text-gray-600">Projected</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Impact Breakdown */}
      <section className="py-20 bg-white">
        <div className="max-w-6xl mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <SectionHeading
                title="Where Your Donations Go"
                subtitle="Breakdown of program funding allocation"
                centered={false}
              />
              <div className="space-y-4">
                {impactBreakdown.map((item) => (
                  <div key={item.name} className="flex items-center gap-4">
                    <div 
                      className="w-4 h-4 rounded-full" 
                      style={{ backgroundColor: item.color }}
                    />
                    <div className="flex-1">
                      <div className="flex justify-between mb-1">
                        <span className="font-medium text-gray-900">{item.name}</span>
                        <span className="font-bold" style={{ color: item.color }}>{item.value}%</span>
                      </div>
                      <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                        <motion.div
                          initial={{ width: 0 }}
                          whileInView={{ width: `${item.value}%` }}
                          viewport={{ once: true }}
                          transition={{ duration: 1, ease: "easeOut" }}
                          className="h-full rounded-full"
                          style={{ backgroundColor: item.color }}
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div className="flex justify-center">
              <ResponsiveContainer width={300} height={300}>
                <RechartsPie>
                  <Pie
                    data={impactBreakdown}
                    dataKey="value"
                    nameKey="name"
                    cx="50%"
                    cy="50%"
                    outerRadius={120}
                    innerRadius={60}
                    paddingAngle={5}
                  >
                    {impactBreakdown.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </RechartsPie>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      </section>

      {/* Health & Education Stats */}
      <section className="py-20 bg-gradient-to-br from-gray-900 to-gray-800">
        <div className="max-w-6xl mx-auto px-4">
          <SectionHeading
            title="Measuring Real Change"
            subtitle="Before and after metrics from our program communities"
            light
          />

          <div className="grid md:grid-cols-2 gap-6">
            {healthStats.map((stat, index) => (
              <motion.div
                key={stat.metric}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 border border-white/10"
              >
                <h3 className="text-white font-semibold mb-4">{stat.metric}</h3>
                <div className="grid grid-cols-3 gap-4 text-center">
                  <div>
                    <div className="text-2xl font-bold text-gray-400">{stat.before}</div>
                    <div className="text-xs text-gray-500 uppercase">Before</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-emerald-400">{stat.after}</div>
                    <div className="text-xs text-gray-500 uppercase">After</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-rose-400">+{stat.improvement}</div>
                    <div className="text-xs text-gray-500 uppercase">Improvement</div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Downloadable Reports */}
      <section className="py-20 bg-white">
        <div className="max-w-6xl mx-auto px-4">
          <SectionHeading
            title="Impact Reports"
            subtitle="Download our comprehensive reports for detailed insights"
          />

          <div className="grid md:grid-cols-3 gap-6">
            {[
              { title: 'Annual Report 2024', type: 'annual', year: 2024 },
              { title: 'Q3 2024 Impact Summary', type: 'quarterly', year: 2024 },
              { title: 'Financial Audit 2023', type: 'audit', year: 2023 },
            ].map((report, index) => (
              <motion.div
                key={report.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="bg-gray-50 rounded-2xl p-6 hover:shadow-lg transition-shadow"
              >
                <div className="w-12 h-12 rounded-xl bg-rose-100 flex items-center justify-center mb-4">
                  <Download className="w-6 h-6 text-rose-600" />
                </div>
                <h3 className="font-bold text-gray-900 mb-2">{report.title}</h3>
                <p className="text-sm text-gray-500 mb-4">PDF Document</p>
                <Button variant="outline" className="w-full">
                  <Download className="w-4 h-4 mr-2" />
                  Download
                </Button>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-gradient-to-r from-rose-600 to-amber-600">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
            Be Part of Our Next Milestone
          </h2>
          <p className="text-xl text-white/90 mb-8">
            Help us reach 1 million girls by 2030. Every donation creates measurable change.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Link to={createPageUrl('Donate')}>
              <Button size="lg" className="bg-white text-rose-600 hover:bg-gray-100">
                <Heart className="w-5 h-5 mr-2" />
                Donate Now
              </Button>
            </Link>
            <Link to={createPageUrl('Transparency')}>
              <Button size="lg" variant="outline" className="border-2 border-white text-white hover:bg-white/10">
                View Financials
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}