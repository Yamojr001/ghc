import React from 'react';
import { HashRouter as Router, Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';

// Common Components
import Header from '@/components/common/Header';
import Footer from '@/components/common/Footer';

// Public Pages
import Home from '@/pages/Home';
import About from '@/pages/About';
import Programs from '@/pages/Programs';
import Impact from '@/pages/Impact';
import Donate from '@/pages/Donate';
import DonorsBoard from '@/pages/DonorsBoard';
import Transparency from '@/pages/Transparency';
import Blog from '@/pages/Blog';
import Gallery from '@/pages/Gallery';
import Volunteer from '@/pages/Volunteer';
import Contact from '@/pages/Contact';
import Team from '@/pages/Team';
import FAQ from '@/pages/FAQ';
import Privacy from '@/pages/Privacy';
import Terms from '@/pages/Terms';
import ChildProtection from '@/pages/ChildProtection';
import Cookies from '@/pages/Cookies';
import Login from '@/pages/Loging';

// Admin Pages
import AdminDashboard from '@/pages/admin/AdminDashboard';
import AdminDonations from '@/pages/admin/AdminDonations';
import AdminDistributions from '@/pages/admin/AdminDistributions';
import AdminExpenses from '@/pages/admin/AdminExpenses';
import AdminUsers from '@/pages/admin/AdminUsers';
import AdminContent from '@/pages/admin/AdminContent';
import AdminReports from '@/pages/admin/AdminReports';
import FieldOfficer from '@/pages/admin/FieldOfficer';

const adminPages = [
  '/AdminDashboard', 
  '/AdminDonations', 
  '/AdminDistributions', 
  '/AdminExpenses', 
  '/AdminUsers', 
  '/AdminContent', 
  '/AdminReports', 
  '/FieldOfficer'
];

const Layout = ({ children }: { children?: React.ReactNode }) => {
  const location = useLocation();
  const isAdminPage = adminPages.some(path => location.pathname.startsWith(path));

  if (isAdminPage) {
    return <>{children}</>;
  }

  return (
    <div className="min-h-screen flex flex-col font-sans text-gray-900 bg-gray-50">
      <Header />
      <main className="flex-1">
        {children}
      </main>
      <Footer />
    </div>
  );
};

const queryClient = new QueryClient();

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <Router>
        <Layout>
          <Routes>
            {/* Public Routes */}
            <Route path="/" element={<Home />} />
            <Route path="/Home" element={<Navigate to="/" replace />} />
            <Route path="/About" element={<About />} />
            <Route path="/Programs" element={<Programs />} />
            <Route path="/Impact" element={<Impact />} />
            <Route path="/Donate" element={<Donate />} />
            <Route path="/DonorsBoard" element={<DonorsBoard />} />
            <Route path="/Transparency" element={<Transparency />} />
            <Route path="/Blog" element={<Blog />} />
            <Route path="/Gallery" element={<Gallery />} />
            <Route path="/Volunteer" element={<Volunteer />} />
            <Route path="/Contact" element={<Contact />} />
            <Route path="/Team" element={<Team />} />
            <Route path="/FAQ" element={<FAQ />} />
            <Route path="/Privacy" element={<Privacy />} />
            <Route path="/Terms" element={<Terms />} />
            <Route path="/ChildProtection" element={<ChildProtection />} />
            <Route path="/Cookies" element={<Cookies />} />
            <Route path="/Login" element={<Login />} />
            
            {/* Admin Routes */}
            <Route path="/AdminDashboard" element={<AdminDashboard />} />
            <Route path="/AdminDonations" element={<AdminDonations />} />
            <Route path="/AdminDistributions" element={<AdminDistributions />} />
            <Route path="/AdminExpenses" element={<AdminExpenses />} />
            <Route path="/AdminUsers" element={<AdminUsers />} />
            <Route path="/AdminContent" element={<AdminContent />} />
            <Route path="/AdminReports" element={<AdminReports />} />
            <Route path="/FieldOfficer" element={<FieldOfficer />} />
            
            <Route path="*" element={<div className="pt-32 text-center text-xl">404 - Page Not Found</div>} />
          </Routes>
        </Layout>
      </Router>
    </QueryClientProvider>
  );
}